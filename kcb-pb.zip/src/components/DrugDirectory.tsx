import React, { useState, useEffect, useRef, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Search, Info, ChevronRight, ChevronLeft, Pill, Filter, ShieldAlert, Plus, Edit2, Trash2, X, Save, FileText, ExternalLink, Eye, EyeOff, Loader2, Check, Clock, RefreshCw, Heart, Baby, Car, AlertTriangle, Activity, Zap, FolderTree, Folder, Scissors, Settings, Briefcase, MoveRight, ChevronUp, ChevronDown, Star, Database, AlertCircle, Calendar } from 'lucide-react';
import { Drug, DrugGroup, Ingredient, ManualInteraction } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { db, collection, onSnapshot, query, orderBy, handleFirestoreError, OperationType, setDoc, doc, deleteDoc, storage, getDoc, writeBatch, getDocs } from '../firebase';
import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import DrugGroupManagement from './DrugGroupManagement';
import CatalogManagement from './CatalogManagement';
import ImageEditorModal from './ImageEditorModal';
import DrugDetailModal from './DrugDetailModal';

import ConfirmModal from './ConfirmModal';

interface DrugDirectoryProps {
  canManage: boolean;
  isDarkMode: boolean;
  subHeaderPortalId?: string;
  featureSettings?: any;
  userRole?: string;
  isApproved?: boolean;
  userPowerPoints?: number;
  initialSelectedDrugId?: string | null;
  onClearInitialDrug?: () => void;
  currentUserName?: string;
}

const AutoExpandingTextarea: React.FC<React.TextareaHTMLAttributes<HTMLTextAreaElement>> = (props) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${textarea.scrollHeight}px`;
    }
  }, [props.value]);

  return (
    <textarea
      {...props}
      ref={textareaRef}
      onInput={(e) => {
        e.currentTarget.style.height = 'auto';
        e.currentTarget.style.height = `${e.currentTarget.scrollHeight}px`;
        if (props.onInput) props.onInput(e);
      }}
    />
  );
};

const DrugDirectory: React.FC<DrugDirectoryProps> = ({ 
  canManage, 
  isDarkMode, 
  subHeaderPortalId, 
  featureSettings, 
  userRole, 
  isApproved = false, 
  userPowerPoints = 0,
  initialSelectedDrugId,
  onClearInitialDrug,
  currentUserName = 'Dược sĩ'
}) => {
  const isGuestUser = !userRole;
  const isPendingUser = !!userRole && !isApproved;

  // Power-point threshold helpers
  const canSeeCommonIndications = !isGuestUser && !isPendingUser &&
    (userPowerPoints >= (featureSettings?.commonIndicationsMinPower ?? 0));
  const canSeeIcdSuggestions = !isGuestUser && !isPendingUser &&
    (userPowerPoints >= (featureSettings?.icdSuggestionsMinPower ?? 0));
  const canSeeClosedDrugs = !isGuestUser && !isPendingUser &&
    (userPowerPoints >= (featureSettings?.showClosedDrugsMinPower ?? 0));

  const [drugs, setDrugs] = useState<Drug[]>([]);
  const [drugGroups, setDrugGroups] = useState<DrugGroup[]>([]);
  const [icdList, setIcdList] = useState<any[]>([]);
  const [availableIngredients, setAvailableIngredients] = useState<Ingredient[]>([]);
  const [availableExcipients, setAvailableExcipients] = useState<any[]>([]);
  const [availableCompanies, setAvailableCompanies] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'hidden'>('all');
  const [selectedDrug, setSelectedDrug] = useState<Drug | null>(null);
  const [groupFilter, setGroupFilter] = useState('Tất cả');
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [extracting, setExtracting] = useState(false);
  const [extractedData, setExtractedData] = useState<Partial<Drug> | null>(null);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'drugs' | 'groups' | 'ingredients' | 'excipients' | 'companies'>('drugs');
  const [excipientView, setExcipientView] = useState<'excipients' | 'categories'>('excipients');
  const [ingredientView, setIngredientView] = useState<'search' | 'manage' | 'categories'>('search');
  const mainSearchRef = useRef<HTMLDivElement>(null);
  const [showStickySearch, setShowStickySearch] = useState(false);

  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 1024);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setShowStickySearch(!entry.isIntersecting);
      },
      { threshold: 0, rootMargin: '-60px 0px 0px 0px' }
    );

    if (mainSearchRef.current) {
      observer.observe(mainSearchRef.current);
    }

    return () => observer.disconnect();
  }, []);
  const [searchMode, setSearchMode] = useState<'all' | 'name' | 'ingredient'>('all');
  const [selectedIngredient, setSelectedIngredient] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [ingredientPage, setIngredientPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(30);
  const INGREDIENTS_PER_PAGE = 48;
  const [groupSearchTerm, setGroupSearchTerm] = useState('');
  const [formGroupSearch, setFormGroupSearch] = useState('');
  const [excipientFormSearch, setExcipientFormSearch] = useState('');
  const [isGroupModalOpen, setIsGroupModalOpen] = useState(false);
  const [isIngredientModalOpen, setIsIngredientModalOpen] = useState(false);
  const [isIngredientCategoryModalOpen, setIsIngredientCategoryModalOpen] = useState(false);
  const [isExcipientModalOpen, setIsExcipientModalOpen] = useState(false);
  const [isExcipientCategoryModalOpen, setIsExcipientCategoryModalOpen] = useState(false);
  const [isCompanyModalOpen, setIsCompanyModalOpen] = useState(false);
  const [pdfViewerUrl, setPdfViewerUrl] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'general' | 'dosage' | 'warnings' | 'pharmacology'>('general');
  const [activeSubTab, setActiveSubTab] = useState<string>('');

  useEffect(() => {
    // Reset sub-tab when main tab changes
    const defaultSubTabs: Record<string, string> = {
      general: 'info',
      dosage: 'indications',
      warnings: 'contra',
      pharmacology: 'interactions'
    };
    setActiveSubTab(defaultSubTabs[activeTab] || '');
  }, [activeTab]);

  const SUB_TABS: Record<string, { id: string, label: string }[]> = {
    general: [
      { id: 'info', label: 'Cơ bản' },
      { id: 'composition', label: 'Thành phần' }
    ],
    dosage: [
      { id: 'indications', label: 'Chỉ định' },
      { id: 'administration', label: 'Liều dùng' }
    ],
    warnings: [
      { id: 'contra', label: 'Chống chỉ định' },
      { id: 'adr', label: 'Tác dụng phụ' },
      { id: 'special', label: 'Thận trọng' }
    ],
    pharmacology: [
      { id: 'interactions', label: 'Tương tác' },
      { id: 'properties', label: 'Dược lực/Động' }
    ]
  };

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  // Management state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDrug, setEditingDrug] = useState<Drug | null>(null);
  const [formData, setFormData] = useState<Drug>({
    id: '',
    name: '',
    activeIngredients: [],
    atcCode: '',
    dosageForm: '',
    excipients: '',
    manufacturer: '',
    mechanismOfAction: '',
    indications: [],
    contraindications: [],
    sideEffects: [],
    category: '',
    groupId: '',
    groupIds: [],
    avatarUrl: '',
    pdfUrl: '',
    administrationRoute: '',
    generalAdministration: '',
    isClosed: false,
    isRx: false,
    dosageAndAdministration: [],
    precautions: '',
    pregnancy: '',
    lactation: '',
    driving: '',
    interactions: '',
    specificInteractions: [],
    pharmacodynamics: [],
    pharmacokinetics: [],
    overdose: '',
    updatedAt: '',
    updatedBy: '',
    createdAt: ''
  });

  // Local string states for comma-separated fields
  const [contraindicationsText, setContraindicationsText] = useState(''); // Keep for legacy if needed, but we'll use formData
  const [sideEffectsText, setSideEffectsText] = useState('');
  const [searchingIcdIndex, setSearchingIcdIndex] = useState<number | null>(null);
  const [searchingContraIcdIndex, setSearchingContraIcdIndex] = useState<number | null>(null);
  const [icdQuery, setIcdQuery] = useState('');
  const hasLoadedIcdRef = useRef(false);

  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    indications: true,
    contraindications: true,
    dosage: true,
    interactions: true,
    warnings: true,
    pharmacology: true
  });
  
  // Lock scroll on outer container when a drug is selected (Mobile only)
  useEffect(() => {
    if (!selectedDrug || window.innerWidth >= 1024) return;
    
    const mainContainer = document.querySelector('main');
    if (mainContainer) {
      const originalOverflow = mainContainer.style.overflow;
      mainContainer.style.overflow = 'hidden';
      return () => {
        mainContainer.style.overflow = originalOverflow;
      };
    }
  }, [selectedDrug]);

  const [activeDetailTab, setActiveDetailTab] = useState<'indications' | 'contraindications' | 'dosage' | 'interactions' | 'warnings' | 'side_effects' | 'pharmacology'>('indications');

  const detailTabs = [
    { id: 'indications', label: 'Chỉ định', icon: <Info size={14} /> },
    { id: 'contraindications', label: 'Chống chỉ định', icon: <ShieldAlert size={14} /> },
    { id: 'dosage', label: 'Liều lượng', icon: <Clock size={14} /> },
    { id: 'side_effects', label: 'Tác dụng phụ', icon: <AlertCircle size={14} /> },
    { id: 'interactions', label: 'Tương tác', icon: <RefreshCw size={14} /> },
    { id: 'warnings', label: 'Cảnh báo', icon: <AlertTriangle size={14} /> },
    { id: 'pharmacology', label: 'Dược lý', icon: <Activity size={14} /> }
  ];

  const handleSwipe = (direction: number) => {
    const currentIndex = detailTabs.findIndex(t => t.id === activeDetailTab);
    const nextIndex = currentIndex + direction;
    if (nextIndex >= 0 && nextIndex < detailTabs.length) {
      setActiveDetailTab(detailTabs[nextIndex].id as any);
    }
  };

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  // Image Editor state
  const [isImageEditorOpen, setIsImageEditorOpen] = useState(false);
  const [imageToEdit, setImageToEdit] = useState<string>('');
  const [editingImageType, setEditingImageType] = useState<'avatar'>('avatar');

  // Drug Detail Modal State
  const [detailDrug, setDetailDrug] = useState<Drug | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  const handleShowDrugDetail = (drug: Drug) => {
    setDetailDrug(drug);
    setIsDetailModalOpen(true);
  };

  const handleImageCropConfirm = (croppedImage: string) => {
    if (editingImageType === 'avatar') {
      setFormData({ ...formData, avatarUrl: croppedImage });
    }
    setIsImageEditorOpen(false);
  };

  const openImageEditor = (url: string, type: 'avatar') => {
    if (!url) return;
    setImageToEdit(url);
    setEditingImageType(type);
    setIsImageEditorOpen(true);
  };

  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [confirmData, setConfirmData] = useState<{ id: string, name: string, pdfUrl?: string } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [portalNode, setPortalNode] = useState<HTMLElement | null>(null);

  useEffect(() => {
    if (subHeaderPortalId) {
      const node = document.getElementById(subHeaderPortalId);
      setPortalNode(node);
    }
    return () => {
      // Dọn portal khi component unmount để tránh inject sau khi navigate đi
      setPortalNode(null);
    };
  }, [subHeaderPortalId]);

  useEffect(() => {
    if (initialSelectedDrugId && drugs.length > 0) {
      const drug = drugs.find(d => d.id === initialSelectedDrugId);
      if (drug) {
        // Enforce visibility rules for direct links
        const canSeeThisDrug = !drug.isClosed || (canManage && canSeeClosedDrugs);
        
        if (canSeeThisDrug) {
          setSelectedDrug(drug);
          setViewMode('drugs');
        }
        
        if (onClearInitialDrug) {
          onClearInitialDrug();
        }
      }
    }
  }, [initialSelectedDrugId, drugs, onClearInitialDrug, canManage, canSeeClosedDrugs]);

  useEffect(() => {
    const q = query(collection(db, 'drugs'), orderBy('name'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const drugsData = snapshot.docs.map(doc => {
        const data = doc.data() as Drug;
        return {
          ...data,
          groupIds: data.groupIds || (data.groupId ? [data.groupId] : []),
          indications: data.indications || [],
          contraindications: data.contraindications || [],
          sideEffects: data.sideEffects || []
        };
      });
      setDrugs(drugsData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'drugs');
    });

    const unsubscribeGroups = onSnapshot(query(collection(db, 'drug_groups'), orderBy('order')), (snapshot) => {
      const groups = snapshot.docs.map(doc => doc.data() as DrugGroup);
      setDrugGroups(groups);
    });

    const unsubscribeIngredients = onSnapshot(query(collection(db, 'ingredients'), orderBy('name')), (snapshot) => {
      const ingredients = snapshot.docs.map(doc => doc.data() as Ingredient);
      setAvailableIngredients(ingredients);
    });

    const unsubscribeExcipients = onSnapshot(query(collection(db, 'excipients'), orderBy('name')), (snapshot) => {
      const excipients = snapshot.docs.map(doc => doc.data());
      setAvailableExcipients(excipients);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'excipients');
    });

    const unsubscribeCompanies = onSnapshot(query(collection(db, 'companies'), orderBy('name')), (snapshot) => {
      const companies = snapshot.docs.map(doc => doc.data());
      setAvailableCompanies(companies);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'companies');
    });

    return () => {
      unsubscribe();
      unsubscribeGroups();
      unsubscribeIngredients();
      unsubscribeExcipients();
      unsubscribeCompanies();
    };
  }, []);

  useEffect(() => {
    const shouldLoadIcd = isModalOpen || searchingIcdIndex !== null || searchingContraIcdIndex !== null || !!selectedDrug;
    if (!shouldLoadIcd || hasLoadedIcdRef.current) return;

    hasLoadedIcdRef.current = true;
    const unsubscribeICD = onSnapshot(collection(db, 'icd10'), (snapshot) => {
      const list = snapshot.docs.map(doc => doc.data());
      setIcdList(list);
    });

    return () => {
      unsubscribeICD();
      hasLoadedIcdRef.current = false;
    };
  }, [isModalOpen, searchingIcdIndex, searchingContraIcdIndex, selectedDrug]);

  const [isIcdLookupOpen, setIsIcdLookupOpen] = useState(false);
  const [icdLookupTarget, setIcdLookupTarget] = useState<{ type: 'indication' | 'contraindication'; index: number } | null>(null);

  const [expandedGroupIds, setExpandedGroupIds] = useState<Set<string>>(new Set());

  // Initialize expanded groups with level 0 groups
  useEffect(() => {
    if (drugGroups.length > 0 && expandedGroupIds.size === 0) {
      const level0Ids = drugGroups.filter(g => g.level === 0).map(g => g.id);
      setExpandedGroupIds(new Set(level0Ids));
    }
  }, [drugGroups]);

  const toggleGroupExpand = (groupId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setExpandedGroupIds(prev => {
      const next = new Set(prev);
      if (next.has(groupId)) {
        next.delete(groupId);
      } else {
        next.add(groupId);
      }
      return next;
    });
  };

  const sortedDrugGroups = useMemo(() => {
    const buildTree = (parentId: string | null = null, seen = new Set<string>()): DrugGroup[] => {
      return drugGroups
        .filter(g => g.parentId === parentId)
        .sort((a, b) => (a.order || 0) - (b.order || 0))
        .flatMap(g => {
          if (seen.has(g.id)) return []; // Prevent infinite recursion
          const newSeen = new Set(seen);
          newSeen.add(g.id);
          return [g, ...buildTree(g.id, newSeen)];
        });
    };
    try {
      return buildTree(null);
    } catch (e) {
      console.error("Circular dependency in drug groups:", e);
      return [];
    }
  }, [drugGroups]);

  // Calculate recursive drug counts for each group
  const groupDrugCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    
    const calculateCount = (groupId: string, seen = new Set<string>()): number => {
      // Return cached count if already calculated
      if (counts[groupId] !== undefined) return counts[groupId];
      if (seen.has(groupId)) return 0;
      
      const newSeen = new Set(seen);
      newSeen.add(groupId);
      
      // Count direct drugs in this group (both legacy and new array-based)
      let total = drugs.filter(d => (Array.isArray(d.groupIds) && d.groupIds.includes(groupId)) || d.groupId === groupId).length;
      
      // Add counts from all sub-groups
      const children = drugGroups.filter(g => g.parentId === groupId);
      children.forEach(child => {
        total += calculateCount(child.id, newSeen);
      });
      
      counts[groupId] = total;
      return total;
    };
    
    drugGroups.forEach(g => calculateCount(g.id));
    return counts;
  }, [drugs, drugGroups]);

  // Map each group to a set of all its descendant group IDs (including itself)
  const groupDescendantsMap = useMemo(() => {
    const map: Record<string, Set<string>> = {};
    
    const getDescendants = (id: string): Set<string> => {
      if (map[id]) return map[id];
      const descendants = new Set<string>([id]);
      drugGroups.filter(g => g.parentId === id).forEach(child => {
        getDescendants(child.id).forEach(dId => descendants.add(dId));
      });
      map[id] = descendants;
      return descendants;
    };
    
    drugGroups.forEach(g => getDescendants(g.id));
    return map;
  }, [drugGroups]);

  const uniqueIngredients = useMemo(() => {
    const ingredientsMap = new Map<string, { name: string, drugCount: number }>();
    drugs.forEach(drug => {
      (drug.activeIngredients || []).forEach(ing => {
        const name = (ing.name || '').trim();
        if (!name) return;
        const key = name.toLowerCase();
        const existing = ingredientsMap.get(key);
        if (existing) {
          existing.drugCount++;
        } else {
          ingredientsMap.set(key, { name, drugCount: 1 });
        }
      });
    });
    return Array.from(ingredientsMap.values()).sort((a, b) => a.name.localeCompare(b.name));
  }, [drugs]);

  const filteredIngredients = useMemo(() => {
    return uniqueIngredients.filter(ing => ing.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [uniqueIngredients, searchTerm]);

  const totalIngredientPages = Math.ceil(filteredIngredients.length / INGREDIENTS_PER_PAGE);
  const paginatedIngredients = useMemo(() => {
    const start = (ingredientPage - 1) * INGREDIENTS_PER_PAGE;
    return filteredIngredients.slice(start, start + INGREDIENTS_PER_PAGE);
  }, [filteredIngredients, ingredientPage]);

  const selectedIngredientNames = useMemo(() => {
    if (!selectedIngredient) return new Set<string>();
    
    const searchName = selectedIngredient.toLowerCase();
    const baseIngredient = availableIngredients.find(ai => 
      ai.name.toLowerCase() === searchName ||
      (ai.alias && ai.alias.toLowerCase() === searchName) ||
      (ai.aliases && ai.aliases.some(a => a.toLowerCase() === searchName))
    );
    
    if (!baseIngredient) return new Set([searchName]);
    
    const names = new Set<string>();
    names.add(baseIngredient.name.toLowerCase());
    if (baseIngredient.alias) names.add(baseIngredient.alias.toLowerCase());
    if (baseIngredient.aliases) {
      baseIngredient.aliases.forEach(a => names.add(a.toLowerCase()));
    }
    return names;
  }, [selectedIngredient, availableIngredients]);

  const filteredDrugs = useMemo(() => {
    const term = (searchTerm || '').toLowerCase();

    return drugs.filter(drug => {
      // Visibility logic
      // Only show closed drugs if in management mode AND have enough power points
      if (drug.isClosed && (!canManage || !canSeeClosedDrugs)) return false;

      // Status filter (only applicable in management mode, as general search hides hidden drugs anyway)
      if (canManage) {
        if (statusFilter === 'active' && drug.isClosed) return false;
        if (statusFilter === 'hidden' && !drug.isClosed) return false;
      }

      let matchesSearch = false;
      if (searchMode === 'all') {
        matchesSearch = (drug.name || '').toLowerCase().includes(term) ||
                        (drug.activeIngredients || []).some(ing =>
                           (ing.name || '').toLowerCase().includes(term) ||
                           (ing.amount || '').toLowerCase().includes(term) ||
                           (ing.unit || '').toLowerCase().includes(term)
                        ) ||
                        (drug.atcCode || '').toLowerCase().includes(term);
      } else if (searchMode === 'name') {
        matchesSearch = (drug.name || '').toLowerCase().includes(term);
      } else if (searchMode === 'ingredient') {
        matchesSearch = (drug.activeIngredients || []).some(ing =>
                           (ing.name || '').toLowerCase().includes(term)
                        );
      }

      const matchesGroup = groupFilter === 'Tất cả' || (
        (drug.groupId && groupDescendantsMap[groupFilter]?.has(drug.groupId)) ||
        (drug.groupIds || []).some(id => groupDescendantsMap[groupFilter]?.has(id))
      );
      const matchesIngredient = selectedIngredientNames.size === 0 || (drug.activeIngredients || []).some(
        ing => selectedIngredientNames.has((ing.name || '').toLowerCase())
      );

      return matchesSearch && matchesGroup && matchesIngredient;
    });
  }, [drugs, searchTerm, searchMode, groupFilter, groupDescendantsMap, selectedIngredientNames, canSeeClosedDrugs, canManage, statusFilter]);

  useEffect(() => {
    setCurrentPage(1);
    setIngredientPage(1);
  }, [searchTerm, groupFilter, searchMode, selectedIngredient, viewMode, itemsPerPage]);

  const totalPages = Math.ceil(filteredDrugs.length / itemsPerPage);
  const paginatedDrugs = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredDrugs.slice(start, start + itemsPerPage);
  }, [filteredDrugs, currentPage, itemsPerPage]);

  const filteredExcipients = useMemo(() => {
    if (!excipientFormSearch) return [];
    const term = excipientFormSearch.toLowerCase();
    return availableExcipients.filter(e => 
      e.name.toLowerCase().includes(term) ||
      (e.alias && e.alias.toLowerCase().includes(term)) ||
      (e.aliases && e.aliases.some((a: string) => a.toLowerCase().includes(term)))
    ).slice(0, 10);
  }, [availableExcipients, excipientFormSearch]);

  const handleOpenModal = (drug?: Drug) => {
    setSelectedFile(null);
    setFormGroupSearch('');
    setExcipientFormSearch('');
    if (drug) {
      setEditingDrug(drug);
      const groupIds = drug.groupIds || (drug.groupId ? [drug.groupId] : []);
      const initialData = { 
        ...drug, 
        groupIds,
        groupId: drug.groupId || '',
        avatarUrl: drug.avatarUrl || '',
        pdfUrl: drug.pdfUrl || '',
        administrationRoute: drug.administrationRoute || '',
        isRx: !!drug.isRx,
        activeIngredients: (drug.activeIngredients || []).map((ing: any) => {
          if ('strength' in ing && !ing.amount && !ing.unit) {
            const match = String(ing.strength).match(/^([\d.,]+)\s*(.*)$/);
            return {
              name: ing.name,
              amount: match ? match[1] : ing.strength,
              unit: match ? match[2] : ''
            };
          }
          return {
            name: ing.name,
            amount: ing.amount || '',
            unit: ing.unit || ''
          };
        }),
        generalAdministration: drug.generalAdministration || '',
        atcCode: drug.atcCode || '',
        excipients: drug.excipients || '',
        indications: (drug.indications || []).map((i: any) => ({
          ...i,
          icd10s: i.icd10s || (i.icd10 ? [i.icd10] : []),
          defaultIcd10s: i.defaultIcd10s || (i.defaultIcd10 ? [i.defaultIcd10] : [])
        })),
        contraindications: (drug.contraindications || []).map((c: any) => 
          typeof c === 'string' ? { content: c, type: 'Other' } : c
        ),
        sideEffects: (drug.sideEffects || []).map((se: any) => 
          typeof se === 'string' ? { frequency: 'Chung', content: se } : se
        ),
        dosageAndAdministration: drug.dosageAndAdministration || [],
        precautions: drug.precautions || '',
        pregnancy: drug.pregnancy || '',
        lactation: drug.lactation || '',
        driving: drug.driving || '',
        interactions: drug.interactions || '',
        pharmacodynamics: Array.isArray(drug.pharmacodynamics) ? drug.pharmacodynamics : (drug.pharmacodynamics ? [{ category: 'Chung', content: drug.pharmacodynamics }] : []),
        pharmacokinetics: Array.isArray(drug.pharmacokinetics) ? drug.pharmacokinetics : (drug.pharmacokinetics ? [{ category: 'Chung', content: drug.pharmacokinetics }] : []),
        specificInteractions: drug.specificInteractions || [],
        overdose: drug.overdose || ''
      };
      setFormData(initialData);
      setSideEffectsText(Array.isArray(initialData.sideEffects) ? initialData.sideEffects.map((se: any) => typeof se === 'string' ? se : se.content).join(', ') : '');
    } else {
      setEditingDrug(null);
      setFormData({
        id: Math.random().toString(36).substr(2, 9),
        name: '',
        activeIngredients: [],
        atcCode: '',
        dosageForm: '',
        excipients: '',
        manufacturer: '',
        mechanismOfAction: '',
        indications: [{ content: '', icd10s: [], defaultIcd10s: [] }],
        contraindications: [{ content: '', type: 'Other' }],
        sideEffects: [],
        category: '',
        groupId: '',
        groupIds: [],
        avatarUrl: '',
        pdfUrl: '',
        administrationRoute: '',
        isClosed: false,
        isRx: false,
        generalAdministration: '',
        dosageAndAdministration: [],
        precautions: '',
        pregnancy: '',
        lactation: '',
        driving: '',
        interactions: '',
        pharmacodynamics: [],
        pharmacokinetics: [],
        overdose: ''
      });
      setContraindicationsText('');
      setSideEffectsText('');
    }
    setIsModalOpen(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) { // 10MB limit for Storage
        alert("File PDF quá lớn (tối đa 10MB).");
        return;
      }
      setSelectedFile(file);
      // Temporary URL for preview/feedback
      setFormData({ ...formData, pdfUrl: URL.createObjectURL(file) });
    }
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setFormData({ ...formData, pdfUrl: '' });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) {
      alert("Vui lòng nhập tên thuốc.");
      return;
    }
    if ((formData.activeIngredients || []).length === 0) {
      alert("Vui lòng thêm ít nhất một hoạt chất.");
      return;
    }

    // handleRemoveFile(); // Removed automatic cleanup to preserve existing PDFs

    setUploading(true);
    setUploadProgress(0);
    try {
      let finalPdfUrl = formData.pdfUrl; // Preserve existing PDF URL

      // If a new file was selected, upload it to Firebase Storage
      // Đã bị vô hiệu hóa theo yêu cầu người dùng để tránh lỗi upload khi dùng AI
      if (false && selectedFile) {
        console.log("Starting upload to Storage...", selectedFile.name);
        const storageRef = ref(storage, `drug-pdfs/${formData.id}_${selectedFile.name}`);
        
        const uploadTask = uploadBytesResumable(storageRef, selectedFile);

        // Track progress
        uploadTask.on('state_changed', 
          (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            setUploadProgress(progress);
            console.log('Upload is ' + progress + '% done');
          }
        );

        // Await the task completion
        await uploadTask;
        
        // Get the download URL
        finalPdfUrl = await getDownloadURL(storageRef);
        console.log("Upload complete. URL:", finalPdfUrl);
      }

      // Parse comma-separated strings into arrays
      const parseList = (text: any) => {
        if (typeof text !== 'string') return [];
        return text.split(',').map(s => s.trim()).filter(s => s !== '');
      };

      const drugData = { 
        ...formData, 
        pdfUrl: finalPdfUrl,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUserName || 'Hệ thống',
        createdAt: editingDrug ? (formData.createdAt || new Date().toISOString()) : new Date().toISOString(),
        indications: formData.indications.filter(i => i && typeof i.content === 'string' && i.content.trim() !== ''),
        contraindications: formData.contraindications.filter(c => c && typeof c.content === 'string' && c.content.trim() !== ''),
        sideEffects: Array.isArray(formData.sideEffects) 
          ? formData.sideEffects.filter((se: any) => {
              if (typeof se === 'string') return se.trim() !== '';
              return se && se.content && se.content.trim() !== '';
            })
          : parseList(sideEffectsText)
      };

      const extractIcdCodes = (indications: any[] = []) => {
        return Array.from(new Set(
          indications
            .flatMap(ind => ind?.icd10s || [])
            .map((code: string) => (code || '').trim())
            .filter((code: string) => !!code)
        ));
      };

      try {
        const drugRef = doc(db, 'drugs', formData.id);
        await setDoc(drugRef, drugData);

        // SYNC INTERACTIONS TO MANUAL_INTERACTIONS LIST
        try {
          const batch = writeBatch(db);
          const syncItems: any[] = [];
          
          (drugData.specificInteractions || []).forEach((si: any) => {
            if (!si.target || !si.content) return;
            const targetDrug = drugs.find(d => (d.name || '').toLowerCase().trim() === (si.target || '').toLowerCase().trim());
            if (targetDrug) {
              syncItems.push({
                type: 'Thuốc - Thuốc',
                sourceIds: [formData.id, targetDrug.id].sort(),
                sourceNames: [formData.name, targetDrug.name].sort(),
                description: si.content,
                severity: 'medium'
              });
            }
          });
          
          (drugData.contraindications || []).forEach((c: any) => {
            if (c.type === 'Drug' && c.content) {
              const targetDrug = drugs.find(d => 
                (c.content || '').toLowerCase().trim() === (d.name || '').toLowerCase().trim() ||
                (c.content || '').toLowerCase().trim().includes((d.name || '').toLowerCase().trim())
              );
              if (targetDrug) {
                syncItems.push({
                  type: 'Thuốc - Thuốc',
                  sourceIds: [formData.id, targetDrug.id].sort(),
                  sourceNames: [formData.name, targetDrug.name].sort(),
                  description: `Chống chỉ định: ${c.content}`,
                  severity: 'high'
                });
              }
            } else if (c.type === 'ICD-10' && c.content) {
              syncItems.push({
                type: 'Thuốc - ICD-10',
                sourceIds: [formData.id],
                sourceNames: [formData.name],
                targetName: c.content,
                description: `Chống chỉ định cho bệnh lý: ${c.content}`,
                severity: 'high'
              });
            }
          });

          const syncIdsToKeep = new Set<string>();
          syncItems.forEach(item => {
            let syncId = '';
            if (item.type === 'Thuốc - Thuốc') {
              syncId = `INT-AUTO-${item.sourceIds[0]}-${item.sourceIds[1]}`;
            } else {
              const safeContent = item.targetName.toLowerCase()
                .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
                .replace(/[^a-z0-9]/g, '-')
                .substring(0, 50);
              syncId = `INT-AUTO-${formData.id}-${safeContent}`;
            }
            syncIdsToKeep.add(syncId);
            
            const interactionData: ManualInteraction = {
              id: syncId,
              type: item.type,
              sourceIds: item.sourceIds,
              sourceNames: item.sourceNames,
              targetName: item.targetName || '',
              severity: item.severity,
              description: item.description,
              recommendation: 'Tham khảo hướng dẫn chuyên môn và theo dõi sát bệnh nhân.',
              updatedAt: new Date().toISOString(),
              updatedBy: currentUserName
            };
            batch.set(doc(db, 'manual_interactions', syncId), interactionData);
          });

          // Cleanup stale interactions starting with 'INT-AUTO-' that involve this drug but aren't in current list
          try {
            const q = query(collection(db, 'manual_interactions'));
            const snapshot = await getDocs(q);
            snapshot.docs.forEach(docSnap => {
              const data = docSnap.data() as ManualInteraction;
              if (docSnap.id.startsWith('INT-AUTO-') && (data.sourceIds || []).includes(formData.id)) {
                if (!syncIdsToKeep.has(docSnap.id)) {
                  batch.delete(docSnap.ref);
                }
              }
            });
          } catch (cleanupError) {
            console.warn("Error during interaction cleanup:", cleanupError);
          }

          await batch.commit();
        } catch (syncError) {
          console.error("Error syncing interactions:", syncError);
        }

        setIsModalOpen(false);
        setSelectedFile(null); // Clear selected file after successful save
      } catch (firestoreError) {
        handleFirestoreError(firestoreError, OperationType.WRITE, `drugs/${formData.id}`);
      }
    } catch (error: any) {
      console.error("Error saving drug detail:", error);
      let errorMessage = "Lỗi khi lưu thông tin hoặc tải file.";
      
      if (error.code === 'storage/unauthorized') {
        errorMessage = "Lỗi: Không có quyền truy cập Storage. Vui lòng kiểm tra lại cấu hình Firebase Storage Rules.";
      } else if (error.code === 'storage/canceled') {
        errorMessage = "Tải lên đã bị hủy.";
      } else if (error.message) {
        // Check if it's a JSON string from handleFirestoreError
        try {
          const parsed = JSON.parse(error.message);
          if (parsed.error) {
            errorMessage += " Chi tiết: " + parsed.error;
          } else {
            errorMessage += " Chi tiết: " + error.message;
          }
        } catch {
          errorMessage += " Chi tiết: " + error.message;
        }
      }
      
      alert(errorMessage);
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const moveArrayItem = (fieldName: keyof Drug, index: number, direction: 'up' | 'down') => {
    const list = formData[fieldName];
    if (!Array.isArray(list)) return;
    
    const newList = [...list];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= newList.length) return;
    
    [newList[index], newList[targetIdx]] = [newList[targetIdx], newList[index]];
    setFormData(prev => ({ ...prev, [fieldName]: newList }));
  };

  const handleAIExtract = async () => {
    if (!selectedFile) {
      fileInputRef.current?.click();
      return;
    }

    setExtracting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      const base64Data = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = (reader.result as string).split(',')[1];
          resolve(base64);
        };
        reader.readAsDataURL(selectedFile);
      });

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            parts: [
              { text: "Bạn là một chuyên gia trích xuất dữ liệu y tế. Trích xuất thông tin thuốc từ PDF. QUY TẮC BẮT BUỘC:\n1. CHỈ trả về JSON thô, KHÔNG giải thích, KHÔNG ghi chú.\n2. SIÊU SÚC TÍCH: Tóm tắt các đoạn văn dài thành 2-3 ý chính ngắn gọn. TUYÊT ĐỐI KHÔNG lặp lại thông tin.\n3. Trường 'unit' (đơn vị), 'amount' (hàm lượng), 'atcCode' CHỈ chứa giá trị thô cực ngắn (ví dụ: 'mg', '10', 'A10BA02'). KHÔNG GIẢI THÍCH TRONG CÁC TRƯỜNG NÀY.\n4. GIỚI HẠN ĐỘ DÀI TOÀN BỘ JSON: Phải nhỏ hơn 15,000 ký tự. Nếu nội dung PDF quá dài, hãy cắt bỏ các phần ít quan trọng, chỉ giữ lại thông tin y khoa thiết yếu nhất.\n5. Đảm bảo cấu trúc JSON hoàn chỉnh. Nếu thông tin không có, trả về chuỗi rỗng hoặc mảng rỗng.\n\nCấu trúc các trường:\n- name: Tên thuốc\n- activeIngredients: [{name, amount, unit}]\n- excipients: Tá dược\n- atcCode: Mã ATC\n- indications: [{content, icd10s: string[]}]\n- contraindications: [{content, type}]\n- sideEffects: [string]\n- generalAdministration: Cách dùng chung\n- dosageAndAdministration: [{category, content}]\n- precautions: Thận trọng (tóm tắt cực ngắn)\n- driving: 'An toàn' hoặc 'Không an toàn'\n- pregnancy/lactation: 'An toàn', 'Chưa thiết lập', 'Cân nhắc lợi ích', hoặc 'Không an toàn'\n- pharmacodynamics/pharmacokinetics: [{category, content}] (Tóm tắt ý chính)" },
              { inlineData: { data: base64Data, mimeType: "application/pdf" } }
            ]
          }
        ],
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          maxOutputTokens: 8192,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              activeIngredients: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    amount: { type: Type.STRING },
                    unit: { type: Type.STRING }
                  }
                } 
              },
              excipients: { type: Type.STRING },
              atcCode: { type: Type.STRING },
              indications: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT,
                  properties: {
                    content: { type: Type.STRING },
                    icd10s: { type: Type.ARRAY, items: { type: Type.STRING } }
                  }
                } 
              },
              contraindications: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT,
                  properties: {
                    content: { type: Type.STRING },
                    type: { type: Type.STRING, enum: ['Drug', 'ICD-10', 'Weight', 'Age', 'Other'] }
                  }
                } 
              },
              sideEffects: { type: Type.ARRAY, items: { type: Type.STRING } },
              generalAdministration: { type: Type.STRING },
              dosageAndAdministration: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT,
                  properties: {
                    category: { type: Type.STRING },
                    content: { type: Type.STRING }
                  }
                } 
              },
              precautions: { type: Type.STRING },
              driving: { type: Type.STRING },
              pregnancy: { type: Type.STRING },
              lactation: { type: Type.STRING },
              interactions: { type: Type.STRING },
              specificInteractions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    target: { type: Type.STRING },
                    content: { type: Type.STRING }
                  }
                }
              },
              pharmacodynamics: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    category: { type: Type.STRING },
                    content: { type: Type.STRING }
                  }
                }
              },
              pharmacokinetics: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    category: { type: Type.STRING },
                    content: { type: Type.STRING }
                  }
                }
              },
              overdose: { type: Type.STRING },
              dosageForm: { type: Type.STRING },
              manufacturer: { type: Type.STRING },
              category: { type: Type.STRING }
            },
            required: ["name", "activeIngredients"]
          }
        }
      });

      let text = (response.text || '{}').trim();
      
      // Basic JSON cleanup if needed
      const cleanJson = (str: string) => {
        let cleaned = str.trim();
        if (cleaned.startsWith('```json')) cleaned = cleaned.replace(/^```json/, '');
        else if (cleaned.startsWith('```')) cleaned = cleaned.replace(/^```/, '');
        if (cleaned.endsWith('```')) cleaned = cleaned.replace(/```$/, '');
        cleaned = cleaned.trim();

        try {
          return JSON.parse(cleaned);
        } catch (e) {
          console.warn("Initial JSON parse failed, attempting stack-based repair...", e);
          
          let fixed = cleaned;
          const stack: string[] = [];
          let inString = false;
          let escaped = false;
          
          for (let i = 0; i < fixed.length; i++) {
            const char = fixed[i];
            if (escaped) {
              escaped = false;
              continue;
            }
            if (char === '\\') {
              escaped = true;
              continue;
            }
            if (char === '"') {
              inString = !inString;
              continue;
            }
            if (!inString) {
              if (char === '{') stack.push('}');
              else if (char === '[') stack.push(']');
              else if (char === '}' || char === ']') {
                if (stack.length > 0 && stack[stack.length - 1] === char) {
                  stack.pop();
                }
              }
            }
          }

          if (inString) fixed += '"';
          while (stack.length > 0) {
            fixed += stack.pop();
          }
          
          try {
            return JSON.parse(fixed);
          } catch (inner) {
            console.warn("Stack-based repair failed, attempting last-resort cutoff repair...");
            const lastBrace = cleaned.lastIndexOf('}');
            const lastBracket = cleaned.lastIndexOf(']');
            const cutoff = Math.max(lastBrace, lastBracket);
            if (cutoff > 0) {
              try {
                return JSON.parse(cleaned.substring(0, cutoff + 1));
              } catch (final) {
                throw e; 
              }
            }
            throw e;
          }
        }
      };

      try {
        const result = cleanJson(text);
        setExtractedData(result);
        setIsReviewModalOpen(true);
      } catch (parseError) {
        console.error("JSON Parse failed:", parseError, "Text preview:", text.substring(0, 1000) + "...");
        alert("Dữ liệu từ AI bị lỗi định dạng (Unterminated string). Vui lòng thử lại với file PDF khác hoặc tóm tắt hơn.");
      }
    } catch (error) {
      console.error("AI Extraction failed:", error);
      alert("Không thể trích xuất thông tin. Vui lòng kiểm tra file PDF hoặc thử lại.");
    } finally {
      setExtracting(false);
    }
  };

  const applyExtractedData = () => {
    if (extractedData) {
      const updatedData = {
        ...formData,
        ...extractedData,
        activeIngredients: extractedData.activeIngredients || formData.activeIngredients,
        atcCode: extractedData.atcCode || formData.atcCode,
        excipients: extractedData.excipients || formData.excipients,
        indications: (extractedData.indications || formData.indications).map((ind: any) => 
          typeof ind === 'string' ? { content: ind, icd10s: [] } : { ...ind, icd10s: ind.icd10s || (ind.icd10 ? [ind.icd10] : []) }
        ),
        contraindications: (extractedData.contraindications || formData.contraindications).map((c: any) => 
          typeof c === 'string' ? { content: c, type: 'Other' } : c
        ),
        sideEffects: extractedData.sideEffects || formData.sideEffects,
        generalAdministration: extractedData.generalAdministration || formData.generalAdministration,
        dosageAndAdministration: extractedData.dosageAndAdministration || formData.dosageAndAdministration,
        precautions: extractedData.precautions || formData.precautions,
        driving: extractedData.driving || formData.driving,
        pregnancy: extractedData.pregnancy || formData.pregnancy,
        lactation: extractedData.lactation || formData.lactation,
        pharmacodynamics: extractedData.pharmacodynamics || formData.pharmacodynamics,
        pharmacokinetics: extractedData.pharmacokinetics || formData.pharmacokinetics,
        interactions: extractedData.interactions || formData.interactions,
        specificInteractions: extractedData.specificInteractions || formData.specificInteractions,
        overdose: extractedData.overdose || formData.overdose,
      };
      setFormData(updatedData);
      setContraindicationsText((updatedData.contraindications || []).join(', '));
      setSideEffectsText((updatedData.sideEffects || []).join(', '));
      setIsReviewModalOpen(false);
      setExtractedData(null);
    }
  };

  const handleToggleClosed = async (drug: Drug) => {
    try {
      const drugRef = doc(db, 'drugs', drug.id);
      await setDoc(drugRef, { ...drug, isClosed: !drug.isClosed }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `drugs/${drug.id}`);
    }
  };

  const handleDelete = (id: string, name: string, pdfUrl?: string) => {
    setConfirmData({ id, name, pdfUrl });
    setIsConfirmOpen(true);
  };

  const confirmDelete = async () => {
    if (!confirmData) return;
    const { id, name, pdfUrl } = confirmData;
    try {
      // Delete PDF from storage if it exists and is a Firebase Storage URL
      if (pdfUrl && pdfUrl.includes('firebasestorage.googleapis.com')) {
        try {
          const storageRef = ref(storage, pdfUrl);
          await deleteObject(storageRef);
        } catch (storageError) {
          console.warn("Could not delete file from storage:", storageError);
        }
      }
      
      try {
        await deleteDoc(doc(db, 'drugs', id));

        // SYNC DELETE: Remove all manual interactions linked to this drug
        try {
          const batch = writeBatch(db);
          const q = query(collection(db, 'manual_interactions'));
          const snapshot = await getDocs(q);
          snapshot.docs.forEach(docSnap => {
            const data = docSnap.data() as ManualInteraction;
            if (docSnap.id.startsWith('INT-AUTO-') && (data.sourceIds || []).includes(id)) {
              batch.delete(docSnap.ref);
            }
          });
          await batch.commit();
        } catch (syncError) {
          console.warn("Could not cleanup interactions after drug deletion:", syncError);
        }

        if (selectedDrug?.id === id) setSelectedDrug(null);
      } catch (firestoreError) {
        handleFirestoreError(firestoreError, OperationType.DELETE, `drugs/${id}`);
      }
    } catch (error: any) {
      console.error("Error deleting drug:", error);
      let msg = "Lỗi khi xóa thuốc.";
      try {
        const parsed = JSON.parse(error.message);
        if (parsed.error) msg += " Chi tiết: " + parsed.error;
      } catch {
        if (error.message) msg += " Chi tiết: " + error.message;
      }
      setErrorMessage(msg);
      // Re-throw to prevent ConfirmModal from closing if we want it to stay open on error
      // Actually, ConfirmModal now catches it and console.errors it.
      throw error;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  const modes = [
    { id: 'drugs', label: featureSettings?.customTitle || "Tra cứu thuốc", icon: <Pill size={16} /> },
    { id: 'groups', label: "Danh mục nhóm", icon: <FolderTree size={16} /> },
    { id: 'ingredients', label: "Tra cứu hoạt chất", icon: <Activity size={16} /> },
    ...(canManage ? [
      { id: 'excipients', label: "Tá dược", icon: <Database size={16} /> },
      { id: 'companies', label: "Công ty", icon: <Briefcase size={16} /> }
    ] : [])
  ];

  const viewModeToggle = (
    <div className={cn(
      "flex p-1 rounded-2xl gap-1 border w-full lg:w-auto",
      isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100 shadow-sm"
    )}>
      {modes.map((mode) => {
        const isActive = viewMode === mode.id;
        return (
          <button
            key={mode.id}
            type="button"
            onClick={() => setViewMode(mode.id as any)}
            className={cn(
              "relative flex-1 lg:flex-none flex items-center justify-center gap-2 px-3 lg:px-4 py-2 lg:py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all transition-colors active:scale-95 whitespace-nowrap overflow-hidden",
              isActive 
                ? (isDarkMode ? "text-blue-400" : "text-blue-600")
                : (isDarkMode ? "text-slate-500 hover:text-slate-400" : "text-slate-400 hover:text-slate-600")
            )}
          >
            {isActive && (
              <motion.div
                layoutId="activeViewTab"
                className={cn(
                  "absolute inset-0 z-0",
                  isDarkMode ? "bg-blue-500/10 border border-blue-500/20" : "bg-blue-50 border border-blue-100"
                )}
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}
            <span className="relative z-10 shrink-0">{mode.icon}</span>
            <span className="relative z-10 hidden sm:inline-block">{mode.label}</span>
          </button>
        );
      })}
    </div>
  );

  return (
    <div className={cn(
      "p-1.5 lg:px-8 lg:pb-8 lg:pt-8 max-w-full mx-auto min-h-screen transition-colors text-slate-900 dark:text-slate-200",
      isDarkMode ? "bg-slate-950/30" : "bg-slate-50/50"
    )}>
      {/* Mobile Subheader Portal */}
      {portalNode && createPortal(
        <div className="flex items-center justify-end w-full">
          {viewModeToggle}
        </div>,
        portalNode
      )}

      <div className="mb-2 lg:mb-6 flex flex-col lg:flex-row lg:items-center justify-between gap-3 lg:gap-6">
        <div className="hidden lg:block space-y-2">
          <div className={cn(
            "inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
            isDarkMode ? "bg-blue-500/10 text-blue-400 border border-blue-500/20" : "bg-blue-50 text-blue-600 border border-blue-100"
          )}>
            <Pill size={12} />
            Danh mục dược lý
          </div>
          <h2 className={cn("text-2xl lg:text-4xl font-black tracking-tight", isDarkMode ? "text-white" : "text-slate-900")}>
            {featureSettings?.customTitle || (canManage ? "Quản lý danh mục thuốc" : "Tra cứu thuốc")}
          </h2>
          <p className={cn(
            "font-medium max-w-xl transition-colors text-xs lg:text-sm opacity-70",
            isDarkMode ? "text-slate-400" : "text-slate-500"
          )}>
            {canManage 
              ? "Hệ thống cập nhật và quản lý cơ sở dữ liệu thuốc, hoạt chất và danh mục dược lý."
              : "Hệ thống tra cứu thông tin dược lý, tương tác và chỉ định ICD-10 chuẩn y khoa."
            }
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-2">
          <div className="hidden lg:block">
            {viewModeToggle}
          </div>
        </div>
      </div>

      {viewMode !== 'groups' && viewMode !== 'excipients' && (
        <div 
          ref={mainSearchRef}
          className={cn(
            "mb-3 p-1.5 lg:p-3 rounded-2xl lg:rounded-[32px] border transition-all shadow-sm flex flex-col lg:flex-row items-stretch lg:items-center gap-2 lg:gap-3",
            isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
          )}
        >
          <div className="relative flex-1 flex items-center group">
            <Search className="absolute left-3 lg:left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors" size={16} />
            <input
              type="text"
              placeholder={searchMode === 'all' ? "Tìm tên thuốc, hoạt chất, mã ATC..." : searchMode === 'name' ? "Tìm theo tên thuốc..." : "Tìm theo hoạt chất..."}
              className={cn(
                "w-full pl-10 pr-28 lg:pl-12 lg:pr-32 py-2.5 lg:py-4 border-none rounded-xl lg:rounded-2xl focus:ring-0 transition-all text-xs lg:text-sm font-bold",
                isDarkMode ? "bg-slate-800/50 text-white placeholder:text-slate-600" : "bg-slate-50 text-slate-900 placeholder:text-slate-400"
              )}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <div className="absolute right-1.5 lg:right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="p-1.5 hover:bg-rose-500/10 text-slate-400 hover:text-rose-500 rounded-lg transition-all"
                >
                  <X size={16} />
                </button>
              )}
              <select
                value={searchMode}
                onChange={(e) => setSearchMode(e.target.value as any)}
                className={cn(
                  "text-[9px] lg:text-[10px] font-black uppercase tracking-widest py-1 lg:py-1.5 px-2 lg:px-3 rounded-lg lg:rounded-xl border-none focus:ring-0 cursor-pointer transition-all",
                  isDarkMode ? "bg-slate-700 text-slate-300 hover:bg-slate-600" : "bg-white text-slate-600 hover:bg-slate-100 shadow-sm"
                )}
              >
                <option value="all">Tất cả</option>
                <option value="name">Tên</option>
                <option value="ingredient">Hoạt chất</option>
              </select>
            </div>
          </div>
          
          <div className={cn(
            "h-6 lg:h-8 w-px hidden lg:block transition-colors",
            isDarkMode ? "bg-slate-800" : "bg-slate-100"
          )}></div>

          <div className="flex items-center gap-2">
            {viewMode === 'drugs' && (
              <>
                {canManage && (
                  <div className="relative group">
                    <Filter className="absolute left-3 lg:left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors" size={14} />
                    <select
                      className={cn(
                        "w-full sm:w-40 pl-9 lg:pl-11 pr-8 lg:pr-10 py-2.5 lg:py-4 border-none rounded-xl lg:rounded-2xl appearance-none focus:ring-0 cursor-pointer text-xs lg:text-sm font-bold transition-all",
                        isDarkMode ? "bg-slate-800/50 text-slate-300" : "bg-slate-50 text-slate-600"
                      )}
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value as any)}
                    >
                      <option value="all">Tất cả trạng thái</option>
                      <option value="active">Đang hoạt động</option>
                      <option value="hidden">Đang ẩn</option>
                    </select>
                    <ChevronRight className="absolute right-3 lg:right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none rotate-90" size={14} />
                  </div>
                )}
                
                <div className="relative flex-1 sm:w-64 group">
                  <Folder className="absolute left-3 lg:left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors" size={14} />
                  <select
                    className={cn(
                      "w-full pl-9 lg:pl-11 pr-8 lg:pr-10 py-2.5 lg:py-4 border-none rounded-xl lg:rounded-2xl appearance-none focus:ring-0 cursor-pointer text-xs lg:text-sm font-bold transition-all",
                      isDarkMode ? "bg-slate-800/50 text-slate-300" : "bg-slate-50 text-slate-600"
                    )}
                    value={groupFilter}
                    onChange={(e) => setGroupFilter(e.target.value)}
                  >
                    <option value="Tất cả">Tất cả nhóm thuốc</option>
                    {sortedDrugGroups.map(group => (
                      <option key={group.id} value={group.id}>
                        {'\u00A0'.repeat(group.level * 3)}{group.level > 0 ? '└─ ' : ''}{group.name}
                      </option>
                    ))}
                  </select>
                  <ChevronRight className="absolute right-3 lg:right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none rotate-90" size={14} />
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {viewMode === 'excipients' ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className={cn("text-xl font-black hidden sm:block", isDarkMode ? "text-white" : "text-slate-900")}>
              {excipientView === 'excipients' ? 'Quản lý Tá dược' : 'Phân loại Tá dược'}
            </h3>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setExcipientView(excipientView === 'excipients' ? 'categories' : 'excipients')}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition-all text-sm",
                  isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 shadow-sm"
                )}
              >
                {excipientView === 'excipients' ? (
                  <><FolderTree size={16} /> Danh mục phân loại</>
                ) : (
                  <><Database size={16} /> Danh sách tá dược</>
                )}
              </button>
            </div>
          </div>
          <div className="bg-white dark:bg-slate-900 rounded-[32px] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden min-h-[600px]">
            <CatalogManagement
              type={excipientView === 'excipients' ? 'excipient' : 'excipient_category'}
              isDarkMode={isDarkMode}
              onClose={() => setViewMode('drugs')}
              inline={true}
            />
          </div>
        </div>
      ) : viewMode === 'ingredients' ? (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h3 className={cn("text-xl font-black", ingredientView === 'search' && "hidden sm:block", isDarkMode ? "text-white" : "text-slate-900")}>
              {ingredientView === 'search' ? 'Tra cứu theo hoạt chất' : 
               ingredientView === 'manage' ? 'Quản lý Hoạt chất' : 
               'Phân loại Hoạt chất'}
            </h3>
            
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setIngredientView('search')}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition-all text-xs",
                  ingredientView === 'search'
                    ? "bg-blue-600 text-white shadow-lg shadow-blue-500/20"
                    : isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 shadow-sm"
                )}
              >
                <Search size={14} /> Tra cứu
              </button>
              
              {canManage && (
                <>
                  <button
                    type="button"
                    onClick={() => setIngredientView('manage')}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition-all text-xs",
                      ingredientView === 'manage'
                        ? "bg-blue-600 text-white shadow-lg shadow-blue-500/20"
                        : isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 shadow-sm"
                    )}
                  >
                    <FolderTree size={14} /> Phân loại
                  </button>
                </>
              )}

              {selectedIngredient && ingredientView === 'search' && (
                <button 
                  type="button"
                  onClick={() => setSelectedIngredient(null)}
                  className="text-xs font-bold text-rose-500 hover:underline"
                >
                  Xóa lọc
                </button>
              )}
            </div>
          </div>

          {ingredientView === 'search' ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {paginatedIngredients.map((ing, idx) => (
                  <motion.div
                    layout
                    key={idx}
                    onClick={() => {
                      setSelectedIngredient(ing.name);
                      setViewMode('drugs');
                    }}
                    className={cn(
                      "p-4 rounded-2xl border cursor-pointer transition-all hover:shadow-xl group",
                      selectedIngredient === ing.name
                        ? "border-primary bg-primary/5"
                        : isDarkMode ? "bg-slate-900 border-slate-800 hover:border-blue-900" : "bg-white border-slate-100 hover:border-blue-200"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-10 h-10 rounded-xl flex items-center justify-center transition-colors",
                          isDarkMode ? "bg-slate-800 group-hover:bg-blue-900/30" : "bg-blue-50 group-hover:bg-blue-100"
                        )}>
                          <Activity size={20} className="text-blue-600" />
                        </div>
                        <div>
                          <h4 className={cn("font-bold text-sm", isDarkMode ? "text-white" : "text-slate-900")}>{ing.name}</h4>
                          <p className="text-[10px] text-slate-500 font-medium">{ing.drugCount} biệt dược</p>
                        </div>
                      </div>
                      <ChevronRight size={14} className="text-slate-300 group-hover:text-primary transition-colors" />
                    </div>
                  </motion.div>
                ))}
              </div>

              {totalIngredientPages > 1 && (
                <div className={cn(
                  "mt-4 flex flex-wrap items-center justify-center gap-1.5 p-3 rounded-2xl border shadow-sm",
                  isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
                )}>
                  <button
                    type="button"
                    disabled={ingredientPage === 1}
                    onClick={() => {
                      setIngredientPage(prev => Math.max(1, prev - 1));
                      const container = document.querySelector('.drug-list-container');
                      if (container) container.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={cn(
                      "p-1.5 rounded-lg border flex items-center justify-center transition-all active:scale-95 disabled:opacity-50",
                      isDarkMode ? "border-slate-800 hover:bg-slate-800 text-slate-400" : "border-slate-100 hover:bg-slate-50 text-slate-500"
                    )}
                  >
                    <ChevronLeft size={16} />
                  </button>
                  
                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalIngredientPages }, (_, i) => i + 1).map((page) => {
                      const shouldShow = page === 1 || page === totalIngredientPages || Math.abs(page - ingredientPage) <= 1;
                      const isBreak = page !== 1 && page !== totalIngredientPages && !shouldShow && (Math.abs(page - ingredientPage) === 2);

                      if (shouldShow) {
                        return (
                          <button
                            key={page}
                            type="button"
                            onClick={() => {
                              setIngredientPage(page);
                              const container = document.querySelector('.drug-list-container');
                              if (container) container.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            className={cn(
                              "w-8 h-8 rounded-lg text-[10px] font-black transition-all active:scale-90 flex items-center justify-center border",
                              ingredientPage === page
                                ? "bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-500/20"
                                : isDarkMode 
                                  ? "bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700" 
                                  : "bg-slate-50 border-slate-100 text-slate-500 hover:bg-slate-100"
                            )}
                          >
                            {page}
                          </button>
                        );
                      } else if (isBreak) {
                        return <span key={page} className="text-slate-400 font-bold px-1">...</span>;
                      }
                      return null;
                    })}
                  </div>

                  <button
                    type="button"
                    disabled={ingredientPage === totalIngredientPages}
                    onClick={() => {
                      setIngredientPage(prev => Math.min(totalIngredientPages, prev + 1));
                      const container = document.querySelector('.drug-list-container');
                      if (container) container.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={cn(
                      "p-1.5 rounded-lg border flex items-center justify-center transition-all active:scale-95 disabled:opacity-50",
                      isDarkMode ? "border-slate-800 hover:bg-slate-800 text-slate-400" : "border-slate-100 hover:bg-slate-50 text-slate-500"
                    )}
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 rounded-[32px] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden min-h-[600px]">
              <CatalogManagement
                type={ingredientView === 'manage' ? 'ingredient' : 'ingredient_category'}
                isDarkMode={isDarkMode}
                onClose={() => setIngredientView('search')}
                inline={true}
              />
            </div>
          )}
        </div>
      ) : viewMode === 'companies' ? (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h3 className={cn("text-xl font-black", isDarkMode ? "text-white" : "text-slate-900")}>Quản lý Công ty</h3>
          </div>
          <div className="bg-white dark:bg-slate-900 rounded-[32px] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden min-h-[600px]">
            <CatalogManagement
              type="company"
              isDarkMode={isDarkMode}
              onClose={() => setViewMode('drugs')}
              inline={true}
            />
          </div>
        </div>
      ) : viewMode === 'groups' ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className={cn("text-xl font-black hidden sm:block", isDarkMode ? "text-white" : "text-slate-900")}>Danh mục nhóm thuốc</h3>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
              <input
                type="text"
                placeholder="Tìm nhóm thuốc..."
                className={cn(
                  "w-full pl-9 pr-4 py-2 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all text-xs font-medium",
                  isDarkMode ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-900"
                )}
                value={groupSearchTerm}
                onChange={(e) => setGroupSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className={cn(
            "grid gap-3 lg:gap-4",
            groupSearchTerm ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" : "grid-cols-1 max-w-4xl mx-auto"
          )}>
            {(groupSearchTerm 
              ? drugGroups.filter(g => (g.name || '').toLowerCase().includes((groupSearchTerm || '').toLowerCase())).sort((a, b) => (a.order || 0) - (b.order || 0))
              : sortedDrugGroups.filter(g => {
                  // A group is visible if it's top-level OR all its ancestors are expanded
                  if (g.level === 0) return true;
                  
                  let currentParentId = g.parentId;
                  while (currentParentId) {
                    if (!expandedGroupIds.has(currentParentId)) return false;
                    const parent = drugGroups.find(pg => pg.id === currentParentId);
                    currentParentId = parent?.parentId || null;
                  }
                  return true;
                })
            ).map((group, index, array) => {
              const drugCount = groupDrugCounts[group.id] || 0;
              const parent = drugGroups.find(pg => pg.id === group.parentId);
              const hasChildren = drugGroups.some(g => g.parentId === group.id);
              const isExpanded = expandedGroupIds.has(group.id);
              
              // logic to show vertical line if there are more siblings or descendants
              const hasMoreSiblings = !groupSearchTerm && array.slice(index + 1).some(g => g.parentId === group.parentId);
              
              return (
                <motion.div
                  key={group.id}
                  onClick={() => {
                    setGroupFilter(group.id);
                    setViewMode('drugs');
                  }}
                  className={cn(
                    "group p-3 rounded-2xl border cursor-pointer transition-all hover:shadow-xl relative",
                    isDarkMode ? "bg-slate-900 border-slate-800 hover:border-blue-900" : "bg-white border-slate-100 hover:border-blue-200",
                    !groupSearchTerm && group.level === 0 && (isDarkMode ? "bg-blue-900/5 border-blue-900/20" : "bg-blue-50/30 border-blue-100/50")
                  )}
                  style={!groupSearchTerm && group.level > 0 ? { 
                    marginLeft: `${group.level * (window.innerWidth >= 1024 ? 48 : 32)}px` 
                  } : {}}
                >
                  {!groupSearchTerm && group.level > 0 && (
                    <>
                      <div className={cn(
                        "absolute top-1/2 -translate-y-1/2 h-px",
                        "-left-8 w-8 lg:-left-12 lg:w-12",
                        isDarkMode ? "bg-slate-700" : "bg-slate-200"
                      )} />
                      <div className={cn(
                        "absolute top-0 bottom-1/2 w-px",
                        "-left-8 lg:-left-12",
                        isDarkMode ? "bg-slate-700" : "bg-slate-200"
                      )} />
                      {hasMoreSiblings && (
                        <div className={cn(
                          "absolute top-1/2 bottom-0 w-px",
                          "-left-8 lg:-left-12",
                          isDarkMode ? "bg-slate-700" : "bg-slate-200"
                        )} />
                      )}
                    </>
                  )}
                  
                  <div className="flex items-start justify-between mb-2">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center transition-colors shadow-sm relative",
                      group.level === 0 
                        ? (isDarkMode ? "bg-blue-600 text-white" : "bg-blue-600 text-white")
                        : isDarkMode ? "bg-slate-800 text-blue-400 group-hover:bg-blue-900/30" : "bg-blue-50 text-blue-600 group-hover:bg-blue-100"
                    )}>
                      <Folder size={group.level === 0 ? 20 : 16} fill={group.level === 0 ? "currentColor" : "none"} />
                      {hasChildren && !groupSearchTerm && (
                        <button
                          onClick={(e) => toggleGroupExpand(group.id, e)}
                          className={cn(
                            "absolute -right-2 -bottom-2 w-6 h-6 rounded-full border flex items-center justify-center transition-transform duration-75 z-10",
                            isDarkMode ? "bg-slate-800 border-slate-700 text-slate-400" : "bg-white border-slate-200 text-slate-500 shadow-sm",
                            isExpanded ? "rotate-180 bg-blue-500 text-white border-blue-600" : "hover:scale-105"
                          )}
                        >
                          <ChevronDown size={12} />
                        </button>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className={cn(
                        "px-2 py-0.5 rounded-md text-[8px] font-black uppercase tracking-widest border shadow-sm",
                        group.level === 0 
                          ? "bg-amber-100 text-amber-700 border-amber-200" 
                          : group.level === 1 
                            ? "bg-emerald-50 text-emerald-600 border-emerald-100"
                            : "bg-slate-100 text-slate-500 border-slate-200"
                      )}>
                        {group.level === 0 ? "Nhóm lớn" : group.level === 1 ? "Nhóm con" : "Nhóm nhỏ"}
                      </span>
                      <span className={cn(
                        "px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider border",
                        isDarkMode ? "bg-slate-800 text-slate-400 border-slate-700" : "bg-white text-slate-500 border-slate-100"
                      )}>
                        {drugCount} thuốc
                      </span>
                    </div>
                  </div>
                  
                  <h4 className={cn(
                    "font-black group-hover:text-blue-600 transition-colors truncate",
                    isDarkMode ? "text-white" : "text-slate-900",
                    group.level === 0 ? "text-sm lg:text-base" : "text-xs lg:text-sm"
                  )}>
                    {group.name}
                  </h4>
                </motion.div>
              );
            })}
          </div>

          {drugGroups.length === 0 && (
            <div className="text-center py-20">
              <FolderTree size={48} className="mx-auto text-slate-300 mb-4" />
              <p className="text-slate-500 font-bold">Chưa có nhóm thuốc nào được định nghĩa</p>
            </div>
          )}
        </div>
      ) : (
        <div className="w-full">
        <div className={cn(
          "flex flex-col gap-6 transition-all duration-500",
          "min-h-screen"
        )}>
          {/* Quick Search in Sticky Column - Only visible when main search bar is scrolled out */}
          <AnimatePresence>
            {showStickySearch && (
              <motion.div 
                initial={{ opacity: 0, y: -20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20, scale: 0.95 }}
                transition={{ type: "spring", damping: 25, stiffness: 350 }}
                className={cn(
                  "p-2 rounded-2xl border shadow-xl transition-all relative flex items-center group mb-1",
                  isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100 shadow-slate-200/50"
                )}
              >
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors" size={16} />
                <input
                  type="text"
                  placeholder="Tìm thuốc..."
                  className={cn(
                    "w-full pl-10 pr-10 py-2.5 bg-transparent border-none focus:ring-0 text-xs font-black",
                    isDarkMode ? "text-white" : "text-slate-900"
                  )}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <button 
                    type="button"
                    onClick={() => setSearchTerm('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-rose-500 p-1 rounded-full hover:bg-rose-500/10 transition-colors"
                  >
                    <X size={14} />
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          <div className={cn(
            "p-1",
            "flex flex-col gap-3"
          )}>

          {/* Top Pagination Controls */}
          {totalPages > 1 && (
            <div className={cn(
              "flex flex-wrap items-center justify-between gap-4 p-3 lg:p-4 rounded-2xl lg:rounded-3xl border shadow-sm mb-2",
              isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
            )}>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <span className={cn("text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded-md", isDarkMode ? "bg-slate-800 text-slate-400" : "bg-slate-50 text-slate-500 border border-slate-100")}>
                    Trang {currentPage} / {totalPages}
                  </span>
                  <span className={cn("hidden sm:inline text-[10px] font-black uppercase tracking-widest text-slate-400")}>
                    ({filteredDrugs.length} thuốc)
                  </span>
                </div>

                <div className="flex items-center gap-2 border-l border-slate-200 pl-3 ml-1">
                  <span className={cn("text-[9px] font-bold uppercase tracking-wider", isDarkMode ? "text-slate-500" : "text-slate-400")}>Hiển thị:</span>
                  <select
                    value={itemsPerPage}
                    onChange={(e) => setItemsPerPage(Number(e.target.value))}
                    className={cn(
                      "text-[10px] font-bold py-1 px-2 rounded-md border appearance-none cursor-pointer outline-none transition-all",
                      isDarkMode 
                        ? "bg-slate-800 border-slate-700 text-slate-300 hover:border-blue-500" 
                        : "bg-white border-slate-200 text-slate-600 hover:border-blue-400 shadow-sm"
                    )}
                  >
                    {[10, 20, 30, 50, 100].map(val => (
                      <option key={val} value={val}>{val}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => {
                    setCurrentPage(prev => Math.max(1, prev - 1));
                    const scrollElement = document.querySelector('.drug-list-container');
                    if (scrollElement) scrollElement.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={cn(
                    "p-1.5 lg:p-2 rounded-lg lg:rounded-xl border flex items-center justify-center transition-all active:scale-95 disabled:opacity-50",
                    isDarkMode ? "border-slate-800 hover:bg-slate-800 text-slate-400" : "border-slate-100 hover:bg-slate-50 text-slate-500"
                  )}
                >
                  <ChevronLeft size={16} />
                </button>
                <button
                  type="button"
                  disabled={currentPage === totalPages}
                  onClick={() => {
                    setCurrentPage(prev => Math.min(totalPages, prev + 1));
                    const scrollElement = document.querySelector('.drug-list-container');
                    if (scrollElement) scrollElement.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={cn(
                    "p-1.5 lg:p-2 rounded-lg lg:rounded-xl border flex items-center justify-center transition-all active:scale-95 disabled:opacity-50",
                    isDarkMode ? "border-slate-800 hover:bg-slate-800 text-slate-400" : "border-slate-100 hover:bg-slate-50 text-slate-500"
                  )}
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
          )}

          {/* List Header - Hidden on mobile */}
          {paginatedDrugs.length > 0 && (
            <div className={cn(
              "hidden md:grid grid-cols-12 gap-4 px-8 py-2 text-[10px] font-black uppercase tracking-widest transition-colors",
              isDarkMode ? "text-slate-500" : "text-slate-400"
            )}>
              <div className="col-span-5 pl-12 text-blue-500">Tên thuốc & Hoạt chất</div>
              <div className="col-span-4 pl-4 text-indigo-500">Nhóm dược lý</div>
              <div className="col-span-2 pl-4 text-emerald-500">Dạng bào chế</div>
              <div className="col-span-1 text-right pr-2">Thao tác</div>
            </div>
          )}

          {selectedIngredient && (
            <div className={cn(
              "p-3 rounded-2xl border flex items-center justify-between mb-2",
              isDarkMode ? "bg-blue-900/20 border-blue-800" : "bg-blue-50 border-blue-100"
            )}>
              <div className="flex items-center gap-2">
                <Activity size={14} className="text-blue-600" />
                <span className="text-xs font-bold text-blue-700 truncate">Hoạt chất: {selectedIngredient}</span>
              </div>
              <button type="button" onClick={() => setSelectedIngredient(null)} className="text-blue-600 hover:text-blue-800 p-1">
                <X size={14} />
              </button>
            </div>
          )}
          {paginatedDrugs.length > 0 ? (
            paginatedDrugs.map((drug) => (
              <motion.div
                layout
                key={drug.id}
                onClick={() => handleShowDrugDetail(drug)}
                className={cn(
                  "p-3 lg:p-4 rounded-xl lg:rounded-2xl border cursor-pointer transition-all duration-300 relative group flex items-start lg:items-center gap-3 lg:gap-4",
                  drug.isClosed && (isDarkMode ? "opacity-60 bg-slate-900/50" : "opacity-75 bg-slate-50/50"),
                  selectedDrug?.id === drug.id 
                    ? cn(
                        "border-primary ring-4 ring-primary/10 z-20 shadow-lg shadow-primary/10",
                        isDarkMode ? "bg-slate-900" : "bg-white"
                      )
                    : cn(
                        "hover:border-primary/30 shadow-sm hover:shadow-md",
                        isDarkMode ? "bg-slate-900 border-slate-800 hover:bg-slate-800/50" : "bg-white border-slate-100 hover:shadow-slate-100"
                      )
                )}
              >
                {selectedDrug?.id === drug.id && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary shadow-[2px_0_8px_rgba(59,130,246,0.5)] rounded-l-xl lg:rounded-l-2xl"></div>
                )}
                
                <div className={cn(
                  "w-10 h-10 lg:w-12 lg:h-12 rounded-lg lg:rounded-xl flex items-center justify-center shrink-0 border shadow-sm relative overflow-hidden",
                  selectedDrug?.id === drug.id 
                    ? "bg-primary border-primary/50 text-white shadow-primary/20" 
                    : cn(
                        "text-slate-400 group-hover:text-primary",
                        isDarkMode 
                          ? "bg-slate-800 border-slate-700 group-hover:bg-primary/10 group-hover:border-primary/30" 
                          : "bg-slate-50 border-slate-100 group-hover:bg-primary/5 group-hover:border-primary/10",
                        drug.isClosed && (isDarkMode ? "bg-slate-900 border-slate-800 text-slate-600" : "bg-slate-200 border-slate-300 text-slate-400")
                      )
                )}>
                  {drug.avatarUrl ? (
                    <img 
                      src={drug.avatarUrl} 
                      alt={drug.name} 
                      loading="lazy" 
                      className={cn(
                        "w-full h-full object-cover transition-transform duration-700 group-hover:scale-110",
                        drug.isClosed && "grayscale opacity-50"
                      )} 
                      referrerPolicy="no-referrer" 
                    />
                  ) : (
                    <Pill size={20} className={cn("lg:size-6 transition-transform duration-500 group-hover:rotate-12", drug.isClosed && "opacity-40")} />
                  )}
                  {drug.isClosed && (
                    <div className="absolute inset-0 flex items-center justify-center bg-slate-900/60 backdrop-blur-[1px]">
                      <EyeOff size={14} className="text-white" />
                    </div>
                  )}
                </div>
                
                <div className={cn("flex-1 min-w-0 grid grid-cols-1 md:grid-cols-12 gap-2 lg:gap-4 items-start lg:items-center", canManage && "pr-16 md:pr-0")}>
                  <div className="md:col-span-5 min-w-0">
                    <div className="flex items-center gap-2 mb-1 lg:mb-1.5">
                      <h3 className={cn(
                        "font-black text-xs lg:text-sm truncate",
                        isDarkMode ? "text-white group-hover:text-primary" : "text-slate-900 group-hover:text-primary"
                      )}>{drug.name}</h3>
                      {drug.isRx && (
                        <span className="shrink-0 text-[7px] lg:text-[8px] px-1 lg:px-1.5 py-0.5 bg-rose-500/10 text-rose-500 rounded-md font-black border border-rose-500/20">Rx</span>
                      )}
                      {drug.isClosed && (
                        <span className={cn(
                          "shrink-0 text-[7px] lg:text-[8px] px-1 lg:px-1.5 py-0.5 rounded-md font-black border flex items-center gap-1",
                          isDarkMode ? "bg-slate-800 text-slate-400 border-slate-700" : "bg-slate-100 text-slate-500 border-slate-200"
                        )}>
                          <EyeOff size={8} /> ĐANG ẨN
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {(drug.activeIngredients || []).slice(0, 3).map((ing, idx) => (
                        <span key={idx} className={cn(
                          "text-[8px] lg:text-[9px] font-bold px-1.5 py-0.5 rounded-md border transition-colors",
                          isDarkMode ? "bg-slate-800/30 border-slate-700 text-slate-400" : "bg-slate-50 border-slate-100 text-slate-500"
                        )}>
                          {ing.name} {ing.amount}{ing.unit}
                        </span>
                      ))}
                      {(drug.activeIngredients || []).length > 3 && (
                        <span className="text-[8px] text-slate-400 font-bold">...</span>
                      )}
                    </div>
                  </div>

                  <div className="md:col-span-4 md:pl-4">
                    {(drug.category || (drug.groupIds && drug.groupIds.length > 0) || drug.atcCode) ? (
                      <div className="flex flex-row flex-wrap md:flex-col gap-1 items-start">
                        {drug.category && (
                          <span className={cn(
                            "flex items-center gap-1 text-[8px] lg:text-[9px] font-bold px-1.5 lg:px-2 py-0.5 rounded-md border truncate max-w-[150px] lg:max-w-full",
                            isDarkMode ? "bg-slate-800/30 border-slate-700 text-slate-500" : "bg-slate-50 border-slate-100 text-slate-400"
                          )}>
                            <Folder size={8} className="shrink-0" />
                            <span className="truncate">{drug.category}</span>
                          </span>
                        )}
                        {drug.groupIds && drug.groupIds.length > 0 && drugGroups.filter(g => drug.groupIds?.includes(g.id)).slice(0, 1).map((g, idx) => (
                          <span key={idx} className={cn(
                            "flex items-center gap-1 text-[8px] lg:text-[9px] font-bold px-1.5 lg:px-2 py-0.5 rounded-md border truncate max-w-[150px] lg:max-w-full",
                            isDarkMode ? "bg-indigo-900/10 border-indigo-900/20 text-indigo-400" : "bg-indigo-50 border-indigo-100 text-indigo-600"
                          )}>
                            <span className="w-1 h-1 rounded-full bg-current opacity-60"></span>
                            <span className="truncate">{g.name}</span>
                          </span>
                        ))}
                        {drug.atcCode && (
                          <span className={cn(
                            "flex items-center gap-1 text-[8px] lg:text-[9px] font-bold px-1.5 lg:px-2 py-0.5 rounded-md border truncate max-w-[100px] lg:max-w-full",
                            isDarkMode ? "bg-slate-800/50 border-slate-700 text-slate-400" : "bg-slate-100 border-slate-200 text-slate-500"
                          )}>
                             <Activity size={8} className="shrink-0" />
                             ATC: {drug.atcCode}
                          </span>
                        )}
                      </div>
                    ) : (
                      <span className="text-[9px] lg:text-[10px] text-slate-400 italic">Chưa phân nhóm</span>
                    )}
                  </div>

                  <div className="md:col-span-2 md:pl-4">
                    <div className="flex flex-row md:flex-col gap-2 md:gap-1 items-center md:items-start flex-wrap">
                      <span className={cn(
                        "inline-flex items-center gap-1 text-[8px] lg:text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-md",
                        isDarkMode ? "bg-blue-900/20 text-blue-400" : "bg-blue-50 text-blue-600"
                      )}>
                        <Activity size={8} />
                        {drug.dosageForm || 'N/A'}
                      </span>
                      {(drug.administrationRoute || drug.generalAdministration) && (
                        <span className="text-[8px] font-bold text-slate-400 line-clamp-1 italic px-0.5" title={`${drug.administrationRoute || ''}${drug.generalAdministration ? ': ' + drug.generalAdministration : ''}`}>
                          {drug.administrationRoute && <span className={isDarkMode ? "text-emerald-400/80" : "text-emerald-600/80"}>{drug.administrationRoute}</span>}
                          {drug.generalAdministration && (
                            <span className="hidden lg:inline ml-1">{drug.generalAdministration}</span>
                          )}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="hidden md:flex md:col-span-1 justify-end gap-1">
                    {canManage && (
                      <div className="flex items-center gap-1 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                        <button 
                          type="button"
                          onClick={(e) => { e.stopPropagation(); handleToggleClosed(drug); }}
                          title={drug.isClosed ? "Hiện thuốc" : "Ẩn thuốc"}
                          className={cn(
                            "p-2 rounded-xl transition-all hover:scale-110",
                            isDarkMode 
                              ? (drug.isClosed ? "text-amber-500 hover:bg-amber-500/10" : "text-slate-500 hover:text-emerald-500 hover:bg-emerald-500/10") 
                              : (drug.isClosed ? "text-amber-600 hover:bg-amber-50/50" : "text-slate-400 hover:text-emerald-600 hover:bg-emerald-50/50")
                          )}
                        >
                          {drug.isClosed ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                        <button 
                          type="button"
                          onClick={(e) => { e.stopPropagation(); handleOpenModal(drug); }}
                          className={cn(
                            "p-2 rounded-xl transition-all hover:scale-110",
                            isDarkMode ? "text-slate-500 hover:text-primary hover:bg-primary/10" : "text-slate-400 hover:text-primary hover:bg-primary/5"
                          )}
                        >
                          <Edit2 size={14} />
                        </button>
                        <button 
                          type="button"
                          onClick={(e) => { e.stopPropagation(); handleDelete(drug.id, drug.name, drug.pdfUrl); }}
                          className={cn(
                            "p-2 rounded-xl transition-all hover:scale-110",
                            isDarkMode ? "text-slate-500 hover:text-rose-500 hover:bg-rose-500/10" : "text-slate-400 hover:text-rose-500 hover:bg-rose-500/5"
                          )}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Nút Sửa/Xóa - absolute trên mobile */}
                {canManage && (
                  <div className="absolute top-2 right-2 flex md:hidden items-center gap-0.5">
                    <button 
                      type="button"
                      onClick={(e) => { e.stopPropagation(); handleToggleClosed(drug); }}
                      title={drug.isClosed ? "Hiện thuốc" : "Ẩn thuốc"}
                      className={cn(
                        "p-1.5 rounded-lg transition-all hover:scale-110",
                        isDarkMode 
                          ? (drug.isClosed ? "text-amber-500 hover:bg-amber-500/10" : "text-slate-500 hover:text-emerald-500 hover:bg-emerald-500/10") 
                          : (drug.isClosed ? "text-amber-600 hover:bg-amber-50/50" : "text-slate-400 hover:text-emerald-600 hover:bg-emerald-50/50")
                      )}
                    >
                      {drug.isClosed ? <EyeOff size={13} /> : <Eye size={13} />}
                    </button>
                    <button 
                      type="button"
                      onClick={(e) => { e.stopPropagation(); handleOpenModal(drug); }}
                      className={cn(
                        "p-1.5 rounded-lg transition-all hover:scale-110",
                        isDarkMode ? "text-slate-500 hover:text-primary hover:bg-primary/10" : "text-slate-400 hover:text-primary hover:bg-primary/5"
                      )}
                    >
                      <Edit2 size={13} />
                    </button>
                    <button 
                      type="button"
                      onClick={(e) => { e.stopPropagation(); handleDelete(drug.id, drug.name, drug.pdfUrl); }}
                      className={cn(
                        "p-1.5 rounded-lg transition-all hover:scale-110",
                        isDarkMode ? "text-slate-500 hover:text-rose-500 hover:bg-rose-500/10" : "text-slate-400 hover:text-rose-500 hover:bg-rose-500/5"
                      )}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                )}
              </motion.div>
            ))
          ) : (
            <div className={cn(
              "text-center py-20 rounded-3xl border shadow-sm transition-colors",
              isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
            )}>
              <div className={cn(
                "w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4",
                isDarkMode ? "bg-slate-800" : "bg-white"
              )}>
                <Search size={32} className={isDarkMode ? "text-slate-600" : "text-slate-300"} />
              </div>
              <p className={cn("font-bold", isDarkMode ? "text-slate-500" : "text-slate-400")}>Không tìm thấy thuốc phù hợp</p>
              <button 
                type="button"
                onClick={() => { setSearchTerm(''); setGroupFilter('Tất cả'); setSelectedIngredient(null); }}
                className={cn("mt-4 font-bold text-sm hover:underline", isDarkMode ? "text-blue-400" : "text-blue-600")}
              >
                Xóa bộ lọc
              </button>
            </div>
          )}

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className={cn(
              "mt-4 flex flex-wrap items-center justify-between gap-4 p-3 lg:p-4 rounded-2xl lg:rounded-3xl border shadow-sm",
              isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
            )}>
              <div className="flex items-center gap-2">
                <span className={cn("text-[9px] font-bold uppercase tracking-wider", isDarkMode ? "text-slate-500" : "text-slate-400")}>Mỗi trang:</span>
                <select
                  value={itemsPerPage}
                  onChange={(e) => setItemsPerPage(Number(e.target.value))}
                  className={cn(
                    "text-[10px] font-bold py-1 px-2 rounded-md border appearance-none cursor-pointer outline-none transition-all",
                    isDarkMode 
                      ? "bg-slate-800 border-slate-700 text-slate-300 hover:border-blue-500" 
                      : "bg-white border-slate-200 text-slate-600 hover:border-blue-400 shadow-sm"
                  )}
                >
                  {[10, 20, 30, 50, 100].map(val => (
                    <option key={val} value={val}>{val}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto py-1 no-scrollbar">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => {
                    setCurrentPage(prev => Math.max(1, prev - 1));
                    const scrollElement = document.querySelector('.drug-list-container');
                    if (scrollElement) scrollElement.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={cn(
                    "p-1.5 lg:p-2 rounded-lg lg:rounded-xl border flex items-center justify-center transition-all active:scale-95 disabled:opacity-50 disabled:active:scale-100",
                    isDarkMode ? "border-slate-800 hover:bg-slate-800 text-slate-400" : "border-slate-100 hover:bg-slate-50 text-slate-500"
                  )}
                >
                  <ChevronLeft size={16} />
                </button>
                
                <div className="flex items-center gap-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
                    // Show current page, first, last, and window around current
                    const shouldShow = page === 1 || page === totalPages || Math.abs(page - currentPage) <= 1;
                    const isBreak = page !== 1 && page !== totalPages && !shouldShow && (Math.abs(page - currentPage) === 2);

                    if (shouldShow) {
                      return (
                        <button
                          key={page}
                          type="button"
                          onClick={() => {
                            setCurrentPage(page);
                            const scrollElement = document.querySelector('.drug-list-container');
                            if (scrollElement) scrollElement.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className={cn(
                            "w-8 h-8 lg:w-10 lg:h-10 rounded-lg lg:rounded-xl text-[10px] lg:text-sm font-black transition-all active:scale-90 flex items-center justify-center border",
                            currentPage === page
                              ? "bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-500/20"
                              : isDarkMode 
                                ? "bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700" 
                                : "bg-slate-50 border-slate-100 text-slate-500 hover:bg-slate-100"
                          )}
                        >
                          {page}
                        </button>
                      );
                    } else if (isBreak) {
                      return <span key={page} className="text-slate-400 font-bold px-1">...</span>;
                    }
                    return null;
                  })}
                </div>

                <button
                  type="button"
                  disabled={currentPage === totalPages}
                  onClick={() => {
                    setCurrentPage(prev => Math.min(totalPages, prev + 1));
                    const scrollElement = document.querySelector('.drug-list-container');
                    if (scrollElement) scrollElement.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={cn(
                    "p-2 rounded-xl border flex items-center justify-center transition-all active:scale-95 disabled:opacity-50 disabled:active:scale-100",
                    isDarkMode ? "border-slate-800 hover:bg-slate-800 text-slate-400" : "border-slate-100 hover:bg-slate-50 text-slate-500"
                  )}
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )}

      {/* Management Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className={cn(
            "fixed inset-0 z-50 flex flex-col transition-all",
            "p-0"
          )}>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !uploading && setIsModalOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: "spring", damping: 30, stiffness: 300, mass: 0.8 }}
              className={cn(
                "relative w-full h-full shadow-2xl flex flex-col transition-colors overflow-hidden rounded-none",
                isDarkMode ? "bg-slate-900" : "bg-white"
              )}
            >
              <div className={cn(
                "p-4 sm:p-6 lg:p-8 border-b flex items-center justify-between transition-colors shrink-0",
                isDarkMode ? "border-slate-800 bg-slate-900" : "border-slate-100 bg-white"
              )}>
                <div className="flex items-center gap-3 sm:gap-4">
                  <h3 className={cn("text-lg sm:text-2xl font-black tracking-tight transition-colors", isDarkMode ? "text-white" : "text-black")}>
                    {editingDrug ? 'Chỉnh sửa thuốc' : 'Thêm thuốc mới'}
                  </h3>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, isClosed: !formData.isClosed })}
                      className={cn(
                        "relative w-10 h-5 sm:w-12 sm:h-6 rounded-full transition-all duration-300 flex items-center px-1",
                        !formData.isClosed 
                          ? "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]" 
                          : (isDarkMode ? "bg-slate-700" : "bg-slate-300")
                      )}
                    >
                      <motion.div
                        className="w-3 h-3 sm:w-4 sm:h-4 bg-white rounded-full shadow-sm"
                        animate={{ x: !formData.isClosed ? (window.innerWidth < 640 ? 20 : 24) : 0 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                      />
                    </button>
                    <span className={cn("text-[10px] sm:text-xs font-black uppercase tracking-wider", !formData.isClosed ? "text-emerald-600" : (isDarkMode ? "text-slate-500" : "text-slate-400"))}>
                      {!formData.isClosed ? 'Hoạt động' : 'Ẩn'}
                    </span>
                  </div>

                  <label className={cn(
                    "flex items-center gap-2 cursor-pointer px-2 sm:px-3 py-1 sm:py-1.5 rounded-full border shadow-sm transition-colors",
                    formData.isRx ? "bg-rose-500 border-rose-400 text-white" : (isDarkMode ? "bg-slate-800 border-slate-700 text-slate-500" : "bg-white border-slate-200 text-slate-400")
                  )}>
                    <input
                      type="checkbox"
                      checked={formData.isRx || false}
                      onChange={(e) => setFormData({ ...formData, isRx: e.target.checked })}
                      className="hidden"
                    />
                    <span className="text-[10px] sm:text-xs font-black">Rx</span>
                  </label>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    type="submit"
                    form="drug-form"
                    disabled={uploading}
                    className={cn(
                      "flex items-center gap-2 px-3 sm:px-6 py-2 sm:py-2.5 bg-blue-600 text-white rounded-xl sm:rounded-full shadow-lg shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-50",
                      uploading && "animate-pulse"
                    )}
                  >
                    {uploading ? (
                      <>
                        <Loader2 size={18} className="animate-spin" />
                        <span className="hidden sm:inline text-sm sm:text-base font-bold">Đang cập nhật...</span>
                      </>
                    ) : (
                      <>
                        <Save size={18} />
                        <span className="hidden sm:inline text-sm sm:text-base font-bold">
                          {editingDrug ? 'Cập nhật' : 'Lưu thuốc'}
                        </span>
                      </>
                    )}
                  </button>
                  <button 
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      if (!uploading) setIsModalOpen(false);
                    }} 
                    className={cn(
                      "p-2 rounded-full transition-all active:scale-95", 
                      isDarkMode 
                        ? "text-slate-500 hover:bg-rose-900/20 hover:text-rose-400" 
                        : "text-slate-400 hover:bg-rose-50 hover:text-rose-500"
                    )}
                  >
                    <X size={20} className="sm:w-6 sm:h-6" />
                  </button>
                </div>
              </div>

              <div className={cn(
                "flex border-b px-4 sm:px-8 overflow-x-auto scrollbar-hide transition-colors shrink-0",
                isDarkMode ? "border-slate-800 bg-slate-900" : "border-slate-100 bg-white"
              )}>
                {[
                  { id: 'general', label: 'Chung', fullLabel: 'Thông tin chung', icon: <Pill size={18} /> },
                  { id: 'dosage', label: 'Liều dùng', fullLabel: 'Chỉ định & Liều dùng', icon: <Clock size={18} /> },
                  { id: 'warnings', label: 'Cảnh báo', fullLabel: 'Thận trọng & Cảnh báo', icon: <ShieldAlert size={18} /> },
                  { id: 'pharmacology', label: 'Dược lý', fullLabel: 'Dược lý & Tương tác', icon: <Activity size={18} /> },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id as any)}
                    className={cn(
                      "flex-1 sm:flex-none flex items-center justify-center sm:justify-start gap-2 py-3 sm:py-4 px-3 sm:px-4 border-b-2 transition-all font-bold text-xs sm:text-sm whitespace-nowrap",
                      activeTab === tab.id 
                        ? "border-blue-600 text-blue-600" 
                        : cn(
                            "border-transparent",
                            isDarkMode ? "text-slate-500 hover:text-slate-300 hover:border-slate-700" : "text-slate-400 hover:text-slate-600 hover:border-slate-200"
                          )
                    )}
                  >
                    {tab.icon}
                    <span className="hidden sm:inline">{tab.fullLabel}</span>
                  </button>
                ))}
              </div>

              <form id="drug-form" onSubmit={handleSave} className="flex-1 overflow-hidden flex flex-col">
                <div className={cn(
                  "flex-1 overflow-y-auto p-3 sm:p-8 space-y-6 sm:space-y-8 transition-colors custom-scrollbar",
                  isDarkMode ? "bg-slate-900" : "bg-white"
                )}>
                  {/* Sub Tabs Navigator */}
                  <div className={cn(
                    "flex gap-1 p-1 rounded-xl sticky top-0 z-30 transition-colors shadow-sm mb-6",
                    isDarkMode ? "bg-slate-800/80 backdrop-blur-md border border-slate-700" : "bg-slate-100/80 backdrop-blur-md border border-slate-200"
                  )}>
                    {(SUB_TABS[activeTab] || []).map((sub) => (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => setActiveSubTab(sub.id)}
                        className={cn(
                          "flex-1 py-2 px-3 rounded-lg text-[10px] sm:text-xs font-black uppercase tracking-widest transition-all",
                          activeSubTab === sub.id
                            ? (isDarkMode ? "bg-blue-600 text-white shadow-lg shadow-blue-900/40" : "bg-white text-blue-600 shadow-sm border border-blue-100")
                            : (isDarkMode ? "text-slate-500 hover:text-slate-300" : "text-slate-500 hover:text-slate-700")
                        )}
                      >
                        {sub.label}
                      </button>
                    ))}
                  </div>

                  {activeTab === 'general' && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }} 
                      animate={{ opacity: 1, x: 0 }}
                      className="space-y-6 sm:space-y-8"
                    >
                      {activeSubTab === 'info' && (
                        <div className="space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-left-4 duration-300">
                          <div className={cn(
                            "space-y-4 p-4 sm:p-6 rounded-2xl border transition-colors",
                            isDarkMode ? "bg-indigo-900/20 border-indigo-900/30" : "bg-indigo-50/50 border-indigo-100"
                          )}>
                            <div className={cn("flex items-center gap-2 mb-2 transition-colors", isDarkMode ? "text-indigo-400" : "text-indigo-700")}>
                              <FileText size={18} className="sm:w-5 sm:h-5" />
                              <label className="text-[10px] sm:text-sm font-black uppercase tracking-widest">Tài liệu PDF (Tải lên/Dán URL)</label>
                            </div>
                            <div className="flex flex-col gap-3">
                              <input
                                type="text"
                                disabled={uploading}
                                placeholder="Dán URL PDF tại đây..."
                                value={formData.pdfUrl}
                                onChange={(e) => setFormData({ ...formData, pdfUrl: e.target.value })}
                                className={cn(
                                  "flex-1 px-3 sm:px-4 py-3 sm:py-4 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all disabled:opacity-50",
                                  isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-white border-slate-200"
                                )}
                              />
                              <div className="flex flex-wrap gap-2">
                                <input
                                  type="file"
                                  accept="application/pdf"
                                  ref={fileInputRef}
                                  onChange={handleFileChange}
                                  className="hidden"
                                />
                                <button
                                  type="button"
                                  disabled={uploading || extracting}
                                  onClick={() => fileInputRef.current?.click()}
                                  className={cn(
                                    "flex-1 sm:flex-none px-4 sm:px-6 py-2 sm:py-3 border rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 disabled:opacity-50",
                                    isDarkMode ? "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700" : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                                  )}
                                >
                                  <Plus size={16} /> Tải file
                                </button>
                                <button
                                  type="button"
                                  disabled={uploading || extracting}
                                  onClick={handleAIExtract}
                                  className={cn(
                                    "flex-1 sm:flex-none px-4 sm:px-6 py-2 sm:py-3 text-white rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg",
                                    isDarkMode ? "bg-indigo-600 hover:bg-indigo-700 shadow-none" : "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100"
                                  )}
                                >
                                  {extracting ? <Loader2 className="animate-spin" size={16} /> : <FileText size={16} />}
                                  {extracting ? 'Đang trích xuất...' : 'AI Trích xuất'}
                                </button>
                                {formData.pdfUrl && (
                                  <button
                                    type="button"
                                    disabled={uploading || extracting}
                                    onClick={handleRemoveFile}
                                    className={cn(
                                      "px-3 sm:px-4 py-3 sm:py-4 border rounded-xl font-bold transition-all flex items-center gap-2 disabled:opacity-50",
                                      isDarkMode ? "text-rose-400 bg-rose-900/20 border-rose-900/30 hover:bg-rose-900/40" : "text-rose-600 bg-rose-50 border-rose-100 hover:bg-rose-100"
                                    )}
                                    title="Xóa file hiện tại"
                                  >
                                    <Trash2 size={18} />
                                  </button>
                                )}
                              </div>
                            </div>
                            <p className="text-[9px] sm:text-[10px] text-slate-400 italic">* Tải file PDF lên và dùng AI để tự động điền thông tin thuốc.</p>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                            <div>
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest mb-1.5 transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                Tên thuốc <span className="text-rose-500">*</span>
                              </label>
                              <input
                                type="text"
                                required
                                disabled={uploading}
                                value={formData.name || ''}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                className={cn(
                                  "w-full px-3 sm:px-4 py-3 sm:py-4 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all disabled:opacity-50",
                                  isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-slate-50 border-slate-200"
                                )}
                              />
                            </div>
                            <div>
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest mb-1.5 transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                Mã ATC
                              </label>
                              <input
                                type="text"
                                disabled={uploading}
                                value={formData.atcCode || ''}
                                onChange={(e) => setFormData({ ...formData, atcCode: e.target.value })}
                                className={cn(
                                  "w-full px-3 sm:px-4 py-3 sm:py-4 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all disabled:opacity-50",
                                  isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-slate-50 border-slate-200"
                                )}
                                placeholder="Ví dụ: N02BE01"
                              />
                            </div>
                            <div>
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest mb-1.5 transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                Nhóm thuốc <span className="text-rose-500">*</span>
                              </label>

                              {/* Selected Groups Chips */}
                              {formData.groupIds && formData.groupIds.length > 0 && (
                                <div className="flex flex-wrap gap-2 mb-3">
                                  {formData.groupIds.map(id => {
                                    const group = drugGroups.find(g => g.id === id);
                                    if (!group) return null;
                                    return (
                                      <motion.div
                                        initial={{ opacity: 0, scale: 0.8 }}
                                        animate={{ opacity: 1, scale: 1 }}
                                        key={id}
                                        className={cn(
                                          "flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] sm:text-xs font-bold transition-all border",
                                          isDarkMode 
                                            ? "bg-blue-900/30 border-blue-800 text-blue-400" 
                                            : "bg-blue-50 border-blue-200 text-blue-700 shadow-sm"
                                        )}
                                      >
                                        <span>{group.name}</span>
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setFormData(prev => {
                                              const nextIds = (prev.groupIds || []).filter(gid => gid !== id);
                                              return {
                                                ...prev,
                                                groupIds: nextIds,
                                                groupId: nextIds[0] || ''
                                              };
                                            });
                                          }}
                                          className={cn(
                                            "p-0.5 rounded-full transition-colors",
                                            isDarkMode ? "hover:bg-blue-800" : "hover:bg-blue-100"
                                          )}
                                        >
                                          <X size={12} />
                                        </button>
                                      </motion.div>
                                    );
                                  })}
                                </div>
                              )}

                              <div className="mb-2">
                                <div className="relative">
                                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                                  <input
                                    type="text"
                                    placeholder="Tìm kiếm nhóm thuốc..."
                                    value={formGroupSearch}
                                    onChange={(e) => setFormGroupSearch(e.target.value)}
                                    className={cn(
                                      "w-full pl-9 pr-4 py-2 border rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all",
                                      isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                    )}
                                  />
                                  {formGroupSearch && (
                                    <button
                                      type="button"
                                      onClick={() => setFormGroupSearch('')}
                                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                                    >
                                      <X size={14} />
                                    </button>
                                  )}
                                </div>
                              </div>
                              <div className={cn(
                                "border rounded-xl p-3 sm:p-4 max-h-[220px] overflow-y-auto custom-scrollbar space-y-2",
                                isDarkMode ? "bg-slate-800 border-slate-700" : "bg-slate-50 border-slate-200"
                              )}>
                                {sortedDrugGroups
                                  .filter(group => 
                                    !formGroupSearch || 
                                    (group.name || '').toLowerCase().includes((formGroupSearch || '').toLowerCase())
                                  )
                                  .map(group => {
                                  let isSelected = false;
                                  if (Array.isArray(formData.groupIds)) {
                                    isSelected = formData.groupIds.includes(group.id);
                                  } else if (formData.groupId === group.id) {
                                    isSelected = true;
                                  }
                                  return (
                                    <label 
                                      key={group.id} 
                                      className={cn(
                                        "flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-all border",
                                        isSelected 
                                          ? (isDarkMode ? "bg-blue-600/20 border-blue-500/50 text-white" : "bg-blue-50 border-blue-200 text-blue-700 font-bold")
                                          : (isDarkMode ? "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800" : "bg-white border-slate-100 text-slate-600 hover:bg-slate-100")
                                      )}
                                      style={{ marginLeft: `${(group.level || 0) * 20}px` }}
                                    >
                                      <input
                                        type="checkbox"
                                        className="sr-only"
                                        checked={isSelected}
                                        onChange={(e) => {
                                        const checked = e.target.checked;
                                        const targetGroupId = group.id;
                                        setFormData(prev => {
                                          let currentIds = Array.isArray(prev.groupIds)
                                            ? prev.groupIds
                                            : (prev.groupId ? [prev.groupId] : []);
                                          let nextIds = [...currentIds];
                                          if (checked) {
                                            if (!nextIds.includes(targetGroupId)) nextIds.push(targetGroupId);
                                          } else {
                                            nextIds = nextIds.filter(id => id !== targetGroupId);
                                          }
                                          return {
                                            ...prev,
                                            groupIds: nextIds,
                                            groupId: nextIds[0] || ''
                                          };
                                        });
                                      }}
                                      />
                                      <div className={cn(
                                        "w-5 h-5 rounded-md border flex items-center justify-center transition-all",
                                        isSelected ? "bg-blue-600 border-blue-600" : (isDarkMode ? "bg-slate-800 border-slate-700" : "bg-white border-slate-200")
                                      )}>
                                        {isSelected && <Check size={14} className="text-white" strokeWidth={4} />}
                                      </div>
                                      <span className="text-xs">{group.name}</span>
                                    </label>
                                  );
                                })}
                              </div>
                            </div>
                            <div>
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest mb-1.5 transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>Đường dùng</label>
                              <div className="flex flex-wrap gap-2">
                                {['Uống', 'Tiêm bắp (IM)', 'Tiêm tĩnh mạch (IV)', 'Truyền tĩnh mạch', 'Đặt dưới lưỡi', 'Dùng ngoài', 'Đặt âm đạo', 'Đặt trực tràng', 'Hít', 'Xịt mũi'].map(route => (
                                  <button
                                    key={route}
                                    type="button"
                                    onClick={() => setFormData({ ...formData, administrationRoute: route })}
                                    className={cn(
                                      "text-[10px] font-bold px-3 py-1.5 rounded-lg border transition-all",
                                      formData.administrationRoute === route
                                        ? "bg-blue-600 border-blue-600 text-white shadow-md"
                                        : (isDarkMode ? "bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50")
                                    )}
                                  >
                                    {route}
                                  </button>
                                ))}
                              </div>
                            </div>
                            <div>
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest mb-1.5 transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>URL Ảnh đại diện</label>
                              <div className="flex gap-3 sm:gap-4">
                                {formData.avatarUrl && (
                                  <div className="relative group/img">
                                    <div className={cn(
                                      "w-10 h-10 sm:w-12 sm:h-12 rounded-xl overflow-hidden border shrink-0 transition-colors",
                                      isDarkMode ? "border-slate-700" : "border-slate-200"
                                    )}>
                                      <img src={formData.avatarUrl} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => openImageEditor(formData.avatarUrl, 'avatar')}
                                      className="absolute inset-0 bg-blue-600/60 text-white opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center rounded-xl"
                                      title="Chỉnh sửa ảnh"
                                    >
                                      <Scissors size={12} />
                                    </button>
                                  </div>
                                )}
                                <div className="flex-1 flex gap-2">
                                  <input
                                    type="text"
                                    placeholder="Dán URL ảnh..."
                                    value={formData.avatarUrl}
                                    onChange={(e) => setFormData({ ...formData, avatarUrl: e.target.value })}
                                    className={cn(
                                      "flex-1 px-3 sm:px-4 py-3 sm:py-4 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-sm",
                                      isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-white border-slate-200"
                                    )}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {activeSubTab === 'composition' && (
                        <div className="space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                          <div className="space-y-3 sm:space-y-4">
                            <div className="flex items-center justify-between">
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                Thành phần hoạt chất <span className="text-rose-500">*</span>
                              </label>
                              <button
                                type="button"
                                onClick={() => {
                                  const newList = [...(formData.activeIngredients || [])];
                                  newList.push({ name: '', amount: '', unit: '' });
                                  setFormData({ ...formData, activeIngredients: newList });
                                }}
                                className={cn(
                                  "flex items-center gap-1 text-[10px] sm:text-xs font-bold px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg transition-all",
                                  isDarkMode ? "bg-blue-900/30 text-blue-400 hover:bg-blue-900/50" : "bg-blue-50 text-blue-600 hover:bg-blue-100"
                                )}
                              >
                                <Plus size={12} /> Thêm
                              </button>
                            </div>
                            <div className="space-y-2 sm:space-y-3">
                              {(formData.activeIngredients || []).map((ingredient, index) => (
                                <div key={index} className={cn(
                                  "flex gap-2 sm:gap-3 items-start p-3 sm:p-4 rounded-xl border transition-colors",
                                  isDarkMode ? "bg-slate-800 border-slate-700" : "bg-slate-50 border-slate-100"
                                )}>
                                  <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3">
                                    <div className="sm:col-span-1">
                                      <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Hoạt chất</label>
                                      <select
                                        required
                                        value={ingredient.name}
                                        onChange={(e) => {
                                          const newList = [...(formData.activeIngredients || [])];
                                          newList[index] = { ...newList[index], name: e.target.value };
                                          setFormData({ ...formData, activeIngredients: newList });
                                        }}
                                        className={cn(
                                          "w-full px-3 py-2.5 sm:py-3 border rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all appearance-none",
                                          isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                        )}
                                      >
                                        <option value="">-- Chọn hoạt chất --</option>
                                          {availableIngredients.flatMap(ai => {
                                            const options = [{ id: `${ai.id}-main`, value: ai.name, label: ai.name }];
                                            if (ai.alias) {
                                              options.push({ id: `${ai.id}-alias`, value: ai.alias, label: `${ai.alias} (${ai.name})` });
                                            }
                                            if (ai.aliases && ai.aliases.length > 0) {
                                              ai.aliases.forEach((a, k) => {
                                                options.push({ id: `${ai.id}-alias-${k}`, value: a, label: `${a} (${ai.name})` });
                                              });
                                            }
                                            return options;
                                          }).map(opt => (
                                            <option key={opt.id} value={opt.value}>{opt.label}</option>
                                          ))}
                                        {/* Fallback for manually entered ingredients or those not in catalog */}
                                        {ingredient.name && !availableIngredients.some(ai => 
                                          ai.name === ingredient.name || 
                                          ai.alias === ingredient.name || 
                                          (ai.aliases && ai.aliases.includes(ingredient.name))
                                        ) && (
                                          <option value={ingredient.name}>{ingredient.name} (Không có trong danh mục)</option>
                                        )}
                                      </select>
                                    </div>
                                    <div className="grid grid-cols-2 gap-2 sm:contents">
                                      <div>
                                        <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Hàm lượng</label>
                                        <input
                                          type="text"
                                          required
                                          value={ingredient.amount}
                                          onChange={(e) => {
                                            const newList = [...(formData.activeIngredients || [])];
                                            newList[index] = { ...newList[index], amount: e.target.value };
                                            setFormData({ ...formData, activeIngredients: newList });
                                          }}
                                          className={cn(
                                            "w-full px-3 py-2.5 sm:py-3 border rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all font-mono",
                                            isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                          )}
                                          placeholder="500"
                                        />
                                      </div>
                                      <div>
                                        <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Đơn vị</label>
                                        <input
                                          type="text"
                                          required
                                          value={ingredient.unit}
                                          onChange={(e) => {
                                            const newList = [...(formData.activeIngredients || [])];
                                            newList[index] = { ...newList[index], unit: e.target.value };
                                            setFormData({ ...formData, activeIngredients: newList });
                                          }}
                                          className={cn(
                                            "w-full px-3 py-2.5 sm:py-3 border rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all",
                                            isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                          )}
                                          placeholder="mg"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex flex-col gap-1 p-1">
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('activeIngredients', index, 'up')}
                                      disabled={index === 0}
                                      className={cn(
                                        "p-1 rounded-md transition-all",
                                        index === 0 ? "opacity-30 cursor-not-allowed" : (isDarkMode ? "hover:bg-slate-700 text-slate-400 hover:text-blue-400" : "hover:bg-slate-200 text-slate-400 hover:text-blue-600")
                                      )}
                                    >
                                      <ChevronUp size={14} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('activeIngredients', index, 'down')}
                                      disabled={index === (formData.activeIngredients || []).length - 1}
                                      className={cn(
                                        "p-1 rounded-md transition-all",
                                        index === (formData.activeIngredients || []).length - 1 ? "opacity-30 cursor-not-allowed" : (isDarkMode ? "hover:bg-slate-700 text-slate-400 hover:text-blue-400" : "hover:bg-slate-200 text-slate-400 hover:text-blue-600")
                                      )}
                                    >
                                      <ChevronDown size={14} />
                                    </button>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newList = (formData.activeIngredients || []).filter((_, i) => i !== index);
                                      setFormData({ ...formData, activeIngredients: newList });
                                    }}
                                    className={cn(
                                      "p-1.5 sm:p-2 mt-4 sm:mt-5 transition-colors rounded-lg",
                                      isDarkMode ? "text-rose-400 hover:bg-rose-900/20" : "text-rose-500 hover:bg-rose-50"
                                    )}
                                  >
                                    <Trash2 size={16} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                            <div className="relative">
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest mb-1.5 transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                Tá dược
                              </label>
                              <div className="relative group/excipient">
                                <input
                                  type="text"
                                  disabled={uploading}
                                  value={formData.excipients || ''}
                                  onChange={(e) => {
                                    setFormData({ ...formData, excipients: e.target.value });
                                    setExcipientFormSearch(e.target.value.split(/[,;]\s*/).pop() || '');
                                  }}
                                  onFocus={() => {
                                    setExcipientFormSearch(formData.excipients?.split(/[,;]\s*/).pop() || '');
                                  }}
                                  className={cn(
                                    "w-full px-3 sm:px-4 py-3 sm:py-4 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all disabled:opacity-50",
                                    isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-slate-50 border-slate-200"
                                  )}
                                  placeholder="Tinh bột ngô, Povidon..."
                                />
                                
                                <AnimatePresence>
                                  {filteredExcipients.length > 0 && (
                                    <motion.div
                                      initial={{ opacity: 0, y: -10 }}
                                      animate={{ opacity: 1, y: 0 }}
                                      exit={{ opacity: 0, y: -10 }}
                                      className={cn(
                                        "absolute left-0 right-0 top-full mt-2 z-[100] border rounded-2xl shadow-xl overflow-hidden",
                                        isDarkMode ? "bg-slate-800 border-slate-700" : "bg-white border-slate-100"
                                      )}
                                    >
                                      <div className="max-h-60 overflow-y-auto custom-scrollbar p-1">
                                        {filteredExcipients.map((excipient, idx) => (
                                          <button
                                            key={idx}
                                            type="button"
                                            onClick={() => {
                                              const currentParts = (formData.excipients || '').split(/([,;]\s*)/);
                                              // Replace last part if it was the search term
                                              if (currentParts.length > 0 && excipientFormSearch && currentParts[currentParts.length - 1].toLowerCase().includes(excipientFormSearch.toLowerCase())) {
                                                currentParts[currentParts.length - 1] = excipient.name;
                                              } else {
                                                if (formData.excipients && !formData.excipients.trim().endsWith(',') && !formData.excipients.trim().endsWith(';')) {
                                                  currentParts.push(', ', excipient.name);
                                                } else {
                                                  currentParts.push(excipient.name);
                                                }
                                              }
                                              
                                              const nextValue = currentParts.join('');
                                              setFormData({ ...formData, excipients: nextValue });
                                              setExcipientFormSearch('');
                                            }}
                                            className={cn(
                                              "w-full text-left px-4 py-2.5 text-sm rounded-xl transition-all flex items-center gap-2",
                                              isDarkMode ? "hover:bg-slate-700 text-slate-300" : "hover:bg-slate-50 text-slate-600"
                                            )}
                                          >
                                            <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                                            <div className="flex flex-col">
                                              <span className="font-medium">{excipient.name}</span>
                                              {excipient.aliases && excipient.aliases.length > 0 ? (
                                                <span className="text-[10px] text-slate-500 italic">Tên khác: {excipient.aliases.join(', ')}</span>
                                              ) : excipient.alias && (
                                                <span className="text-[10px] text-slate-500 italic">Tên khác: {excipient.alias}</span>
                                              )}
                                            </div>
                                          </button>
                                        ))}
                                      </div>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </div>
                            </div>
                            <div>
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest mb-1.5 transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                Dạng bào chế
                              </label>
                              <input
                                type="text"
                                placeholder="Viên nén, siro,..."
                                disabled={uploading}
                                value={formData.dosageForm || ''}
                                onChange={(e) => setFormData({ ...formData, dosageForm: e.target.value })}
                                className={cn(
                                  "w-full px-3 sm:px-4 py-3 sm:py-4 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all disabled:opacity-50",
                                  isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-slate-50 border-slate-200"
                                )}
                              />
                            </div>
                            <div className="relative group/manufacturer">
                              <div className="flex items-center justify-between mb-1.5">
                                <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                  Nhà sản xuất
                                </label>
                                <button
                                  type="button"
                                  onClick={() => setIsCompanyModalOpen(true)}
                                  className="text-[9px] font-bold text-blue-500 hover:underline"
                                >
                                  Quản lý
                                </button>
                              </div>
                              <input
                                type="text"
                                disabled={uploading}
                                list="company-list"
                                value={formData.manufacturer || ''}
                                onChange={(e) => setFormData({ ...formData, manufacturer: e.target.value })}
                                className={cn(
                                  "w-full px-3 sm:px-4 py-3 sm:py-4 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all disabled:opacity-50",
                                  isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-slate-50 border-slate-200"
                                )}
                                placeholder="Chọn hoặc nhập tên công ty..."
                              />
                              <datalist id="company-list">
                                {availableCompanies.map(company => (
                                  <option key={company.id} value={company.name} />
                                ))}
                              </datalist>
                            </div>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  )}

                  {activeTab === 'dosage' && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }} 
                      animate={{ opacity: 1, x: 0 }}
                      className="space-y-6 sm:space-y-8"
                    >
                      {activeSubTab === 'indications' && (
                        <div className="pt-2 animate-in fade-in slide-in-from-left-4 duration-300 space-y-4 sm:space-y-5">
                          {/* Cơ chế tác dụng */}
                          <div className={cn(
                            "p-4 sm:p-5 rounded-2xl border transition-colors",
                            isDarkMode ? "bg-violet-900/10 border-violet-900/30" : "bg-violet-50/50 border-violet-100"
                          )}>
                            <label className={cn(
                              "block text-[10px] sm:text-xs font-black uppercase tracking-widest mb-2 flex items-center gap-2",
                              isDarkMode ? "text-violet-400" : "text-violet-700"
                            )}>
                              <Zap size={14} />
                              Cơ chế tác dụng
                            </label>
                            <AutoExpandingTextarea
                              rows={2}
                              value={formData.mechanismOfAction || ''}
                              onChange={(e) => setFormData({ ...formData, mechanismOfAction: e.target.value })}
                              className={cn(
                                "w-full px-3 sm:px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-violet-500 transition-all resize-none text-xs sm:text-sm font-medium",
                                isDarkMode ? "bg-slate-900 border-slate-700 text-white placeholder-slate-600" : "bg-white border-violet-100 placeholder-slate-400"
                              )}
                              placeholder="Mô tả cơ chế tác dụng của thuốc, ví dụ: Ức chế enzym COX-2, giảm tổng hợp prostaglandin..."
                            />
                          </div>

                          <div className="flex items-center justify-between">
                            <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest flex items-center gap-2 transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                              <div className="w-1 h-3 sm:h-4 bg-blue-600 rounded-full"></div>
                              Chỉ định & Mã ICD-10
                            </label>
                            <button
                              type="button"
                              onClick={() => {
                                setFormData({
                                  ...formData,
                                  indications: [...(formData.indications || []), { title: '', content: '', icd10s: [] }]
                                });
                              }}
                              className={cn(
                                "text-[10px] sm:text-xs px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg font-bold transition-all flex items-center gap-1",
                                isDarkMode ? "bg-blue-900/30 text-blue-400 hover:bg-blue-900/50" : "bg-blue-50 text-blue-600 hover:bg-blue-100"
                              )}
                            >
                              <Plus size={12} /> Thêm
                            </button>
                          </div>

                          <div className="space-y-2 sm:space-y-3">
                            {(formData.indications || []).map((indication, index) => (
                              <div key={index} className={cn(
                                "flex gap-2 sm:gap-3 items-start p-3 sm:p-4 rounded-2xl border group relative transition-colors",
                                isDarkMode ? "bg-slate-800 border-slate-700" : "bg-slate-50 border-slate-100",
                                indication.isPrimary && (isDarkMode ? "ring-2 ring-amber-500/50 bg-amber-900/10 border-amber-900/30" : "ring-2 ring-amber-500/50 bg-amber-50 border-amber-200")
                              )}>
                                <div className="flex flex-col gap-2 pt-2">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newList = [...formData.indications];
                                      newList[index] = { ...newList[index], isPrimary: !newList[index].isPrimary };
                                      setFormData({ ...formData, indications: newList });
                                    }}
                                    className={cn(
                                      "p-2 rounded-xl transition-all hover:scale-110",
                                      indication.isPrimary 
                                        ? "bg-amber-500 text-white shadow-lg shadow-amber-500/20" 
                                        : (isDarkMode ? "bg-slate-900 text-slate-600 hover:text-amber-400" : "bg-white text-slate-300 hover:text-amber-500 shadow-sm")
                                    )}
                                    title={indication.isPrimary ? "Chỉ định thường dùng" : "Ghim làm chỉ định thường dùng"}
                                  >
                                    <Star size={18} fill={indication.isPrimary ? "currentColor" : "none"} />
                                  </button>
                                </div>
                                <div className="flex-1 space-y-2 sm:space-y-3">
                                  <div className="space-y-1">
                                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Tên chỉ định (Nhãn)</label>
                                    <input
                                      type="text"
                                      value={indication.title || ''}
                                      onChange={(e) => {
                                        const newList = [...formData.indications];
                                        newList[index] = { ...newList[index], title: e.target.value };
                                        setFormData({ ...formData, indications: newList });
                                      }}
                                      className={cn(
                                        "w-full px-3 sm:px-4 py-2 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-xs sm:text-sm font-medium",
                                        isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                      )}
                                      placeholder="Ví dụ: Chỉ định chính, Chỉ định thay thế..."
                                    />
                                  </div>
                                  <div className="space-y-1">
                                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Nội dung chỉ định</label>
                                    <AutoExpandingTextarea
                                      rows={2}
                                      value={indication.content}
                                      onChange={(e) => {
                                        const newList = [...formData.indications];
                                        newList[index] = { ...newList[index], content: e.target.value };
                                        setFormData({ ...formData, indications: newList });
                                      }}
                                      className={cn(
                                        "w-full px-3 sm:px-4 py-3 sm:py-4 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all resize-none text-xs sm:text-sm font-medium",
                                        isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                      )}
                                      placeholder="Giảm đau, hạ sốt..."
                                    />
                                  </div>
                                  <div className="space-y-1">
                                    <div className="flex items-center justify-between ml-1">
                                      <label className={cn("text-[9px] font-black uppercase tracking-widest transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                        Mã ICD-10 gợi ý
                                      </label>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setIcdLookupTarget({ type: 'indication', index });
                                          setIsIcdLookupOpen(true);
                                        }}
                                        className={cn(
                                          "text-[9px] font-black uppercase tracking-widest flex items-center gap-1 transition-colors",
                                          isDarkMode ? "text-blue-400 hover:text-blue-300" : "text-blue-600 hover:text-blue-700"
                                        )}
                                      >
                                        <Database size={10} />
                                        Tra cứu ICD-10
                                      </button>
                                    </div>
                                    <div className="flex flex-wrap gap-1 mb-2">
                                      {(indication.icd10s || []).map((code, tagIdx) => {
                                        const codeOnly = code.split(' - ')[0];
                                        const isDefault = (indication.defaultIcd10s || []).includes(code) || indication.defaultIcd10 === code;
                                        return (
                                          <div 
                                            key={tagIdx} 
                                            className={cn(
                                              "inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold border animate-in fade-in zoom-in duration-200 transition-all",
                                              isDefault
                                                ? "bg-amber-500 text-white border-amber-500 shadow-sm shadow-amber-200"
                                                : isDarkMode ? "bg-blue-500/10 text-blue-400 border-blue-500/20" : "bg-blue-50 text-blue-600 border-blue-100"
                                            )}
                                          >
                                            <button
                                              type="button"
                                              title={isDefault ? "Đang là ICD-10 thường dùng" : "Chọn làm ICD-10 thường dùng"}
                                              onClick={() => {
                                                const newList = [...formData.indications];
                                                const currentDefaults = newList[index].defaultIcd10s || (newList[index].defaultIcd10 ? [newList[index].defaultIcd10] : []);
                                                let nextDefaults;
                                                if (currentDefaults.includes(code)) {
                                                  nextDefaults = currentDefaults.filter(c => c !== code);
                                                } else {
                                                  nextDefaults = [...currentDefaults, code];
                                                }
                                                newList[index] = {
                                                  ...newList[index],
                                                  defaultIcd10s: nextDefaults,
                                                  defaultIcd10: nextDefaults[0] || undefined
                                                };
                                                setFormData({ ...formData, indications: newList });
                                              }}
                                              className={cn(
                                                "transition-colors shrink-0",
                                                isDefault ? "text-white" : (isDarkMode ? "text-blue-500 hover:text-amber-400" : "text-blue-400 hover:text-amber-500")
                                              )}
                                            >
                                              <Star size={9} fill={isDefault ? "currentColor" : "none"} />
                                            </button>
                                            {codeOnly}
                                            <button
                                              type="button"
                                              onClick={() => {
                                                const newList = [...formData.indications];
                                                const nextDefaults = (newList[index].defaultIcd10s || []).filter(c => c !== code);
                                                newList[index] = {
                                                  ...newList[index],
                                                  icd10s: (newList[index].icd10s || []).filter((_, i) => i !== tagIdx),
                                                  defaultIcd10s: nextDefaults,
                                                  defaultIcd10: nextDefaults[0] || undefined
                                                };
                                                setFormData({ ...formData, indications: newList });
                                              }}
                                              className={cn(
                                                "transition-colors",
                                                isDefault ? "hover:text-amber-200" : "hover:text-rose-500"
                                              )}
                                            >
                                              <X size={10} />
                                            </button>
                                          </div>
                                        );
                                      })}
                                    </div>
                                    {(indication.icd10s || []).length > 0 && (
                                      <div className={cn(
                                        "flex items-center gap-2 px-2 py-1 rounded-lg text-[9px] font-bold",
                                        indication.defaultIcd10
                                          ? (isDarkMode ? "text-amber-400" : "text-amber-600")
                                          : (isDarkMode ? "text-slate-500" : "text-slate-400")
                                      )}>
                                        <Star size={9} fill={indication.defaultIcd10 ? "currentColor" : "none"} />
                                        {indication.defaultIcd10
                                          ? `ICD-10 thường dùng: ${indication.defaultIcd10.split(' - ')[0]}`
                                          : "Nhấn ☆ trên mã ICD-10 để chọn làm mặc định khi kê toa"}
                                      </div>
                                    )}
                                    <div className="relative">
                                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={12} />
                                      <input
                                        type="text"
                                        value={searchingIcdIndex === index ? icdQuery : ''}
                                        onChange={(e) => {
                                          setIcdQuery(e.target.value);
                                          setSearchingIcdIndex(index);
                                        }}
                                        onFocus={() => {
                                          setSearchingIcdIndex(index);
                                          setIcdQuery('');
                                        }}
                                        onBlur={() => {
                                          setTimeout(() => setSearchingIcdIndex(null), 200);
                                        }}
                                        className={cn(
                                          "w-full pl-8 sm:pl-9 pr-3 sm:pr-4 py-3 sm:py-4 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-xs sm:text-sm font-bold",
                                          isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                        )}
                                        placeholder="Tìm và thêm mã ICD-10..."
                                      />
                                      {searchingIcdIndex === index && (
                                        <div className={cn(
                                          "absolute z-50 w-full mt-1 border rounded-xl shadow-xl max-h-60 overflow-y-auto transition-colors",
                                          isDarkMode ? "bg-slate-800 border-slate-700" : "bg-white border-slate-200"
                                        )}>
                                          {icdList
                                            .filter(icd => 
                                              (icd.code || '').toLowerCase().includes((icdQuery || '').toLowerCase()) || 
                                              (icd.description || '').toLowerCase().includes((icdQuery || '').toLowerCase())
                                            )
                                            .slice(0, 50)
                                            .map(icd => (
                                              <button
                                                key={icd.code}
                                                type="button"
                                                onClick={() => {
                                                  const newList = [...formData.indications];
                                                  const codeStr = `${icd.code} - ${icd.description}`;
                                                  const currentIcds = newList[index].icd10s || [];
                                                  if (!currentIcds.includes(codeStr)) {
                                                    newList[index] = { 
                                                      ...newList[index], 
                                                      icd10s: [...currentIcds, codeStr] 
                                                    };
                                                    setFormData({ ...formData, indications: newList });
                                                  }
                                                  setSearchingIcdIndex(null);
                                                  setIcdQuery('');
                                                }}
                                                className={cn(
                                                  "w-full text-left px-3 sm:px-4 py-2 text-[10px] sm:text-xs transition-colors border-b last:border-0",
                                                  isDarkMode ? "hover:bg-slate-700 border-slate-700" : "hover:bg-blue-50 border-slate-50"
                                                )}
                                              >
                                                <span className="font-bold text-blue-600">{icd.code}</span>
                                                <span className={cn("ml-2", isDarkMode ? "text-slate-400" : "text-slate-600")}>- {icd.description}</span>
                                              </button>
                                            ))
                                          }
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                                <div className="flex flex-col gap-1 mt-4 sm:mt-6">
                                  <button
                                    type="button"
                                    onClick={() => moveArrayItem('indications', index, 'up')}
                                    disabled={index === 0}
                                    className={cn(
                                      "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                      index === 0 ? "invisible" : (isDarkMode ? "text-slate-500 hover:text-blue-400 hover:bg-blue-900/20" : "text-slate-400 hover:text-blue-600 hover:bg-blue-50")
                                    )}
                                  >
                                    <ChevronUp size={14} />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => moveArrayItem('indications', index, 'down')}
                                    disabled={index === formData.indications.length - 1}
                                    className={cn(
                                      "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                      index === formData.indications.length - 1 ? "invisible" : (isDarkMode ? "text-slate-500 hover:text-blue-400 hover:bg-blue-900/20" : "text-slate-400 hover:text-blue-600 hover:bg-blue-50")
                                    )}
                                  >
                                    <ChevronDown size={14} />
                                  </button>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const newList = formData.indications.filter((_, i) => i !== index);
                                    setFormData({ ...formData, indications: newList });
                                  }}
                                  className={cn(
                                    "mt-5 sm:mt-6 p-1.5 sm:p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100",
                                    isDarkMode ? "text-slate-500 hover:text-rose-400 hover:bg-rose-900/20" : "text-slate-400 hover:text-rose-500 hover:bg-rose-50"
                                  )}
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {activeSubTab === 'administration' && (
                        <div className="pt-2 sm:pt-4 animate-in fade-in slide-in-from-right-4 duration-300">
                          <div className="flex items-center justify-between mb-3 sm:mb-4">
                            <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest flex items-center gap-2 transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                              <div className="w-1 h-3 sm:h-4 bg-blue-600 rounded-full"></div>
                              Liều lượng & Cách dùng
                            </label>
                            <button
                              type="button"
                              onClick={() => {
                                const current = formData.dosageAndAdministration || [];
                                setFormData({
                                  ...formData,
                                  dosageAndAdministration: [...current, { category: '', content: '' }]
                                });
                              }}
                              className={cn(
                                "text-[10px] sm:text-xs px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg font-bold transition-all flex items-center gap-1",
                                isDarkMode ? "bg-blue-900/30 text-blue-400 hover:bg-blue-900/50" : "bg-blue-50 text-blue-600 hover:bg-blue-100"
                              )}
                            >
                              <Plus size={12} /> Thêm
                            </button>
                          </div>
                          <div className="space-y-3 sm:space-y-4">
                            <div className={cn(
                              "p-3 sm:p-5 rounded-2xl border shadow-sm transition-colors",
                              isDarkMode ? "bg-slate-800 border-slate-700" : "bg-white border-slate-200"
                            )}>
                              <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Cách dùng chung (Tất cả đối tượng)</label>
                              <AutoExpandingTextarea
                                rows={1}
                                className={cn(
                                  "w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-blue-500 transition-all font-bold text-sm",
                                  isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-slate-50 border-slate-100 text-slate-900"
                                )}
                                value={formData.generalAdministration || ''}
                                onChange={(e) => setFormData({ ...formData, generalAdministration: e.target.value })}
                                placeholder="Ví dụ: Uống sau bữa ăn 30 phút, sáng và tối..."
                              />
                            </div>

                            {(formData.dosageAndAdministration || []).map((item, index) => (
                              <div key={index} className={cn(
                                "p-3 sm:p-5 rounded-2xl border shadow-sm space-y-3 sm:space-y-4 relative group transition-colors",
                                isDarkMode ? "bg-slate-800 border-slate-700" : "bg-white border-slate-200"
                              )}>
                                <div className="flex flex-col gap-1 absolute top-3 sm:top-4 right-10 sm:right-12">
                                  <button
                                    type="button"
                                    onClick={() => moveArrayItem('dosageAndAdministration', index, 'up')}
                                    disabled={index === 0}
                                    className={cn(
                                      "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                      index === 0 ? "invisible" : (isDarkMode ? "text-slate-600 hover:text-blue-400 hover:bg-blue-900/20" : "text-slate-300 hover:text-blue-600 hover:bg-blue-50")
                                    )}
                                  >
                                    <ChevronUp size={16} />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => moveArrayItem('dosageAndAdministration', index, 'down')}
                                    disabled={index === (formData.dosageAndAdministration || []).length - 1}
                                    className={cn(
                                      "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                      index === (formData.dosageAndAdministration || []).length - 1 ? "invisible" : (isDarkMode ? "text-slate-600 hover:text-blue-400 hover:bg-blue-900/20" : "text-slate-300 hover:text-blue-600 hover:bg-blue-50")
                                    )}
                                  >
                                    <ChevronDown size={16} />
                                  </button>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const newList = (formData.dosageAndAdministration || []).filter((_, i) => i !== index);
                                    setFormData({ ...formData, dosageAndAdministration: newList });
                                  }}
                                  className={cn(
                                    "absolute top-3 sm:top-4 right-3 sm:right-4 p-1.5 sm:p-2 transition-all opacity-0 group-hover:opacity-100 rounded-lg",
                                    isDarkMode ? "text-slate-600 hover:text-red-400 hover:bg-red-900/20" : "text-slate-300 hover:text-red-500 hover:bg-red-50"
                                  )}
                                >
                                  <Trash2 size={16} />
                                </button>
                                <div className="w-full">
                                  <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Đối tượng / Phân loại</label>
                                  <div className="flex flex-wrap gap-1 mb-2">
                                    {[
                                      'Người lớn', 
                                      'Trẻ em', 
                                      'Trẻ em < 2 tuổi', 
                                      'Trẻ em 2-12 tuổi', 
                                      'Người cao tuổi', 
                                      'Suy gan', 
                                      'Suy thận',
                                      'Phụ nữ có thai',
                                      'Phụ nữ cho con bú'
                                    ].map(cat => (
                                      <button
                                        key={cat}
                                        type="button"
                                        onClick={() => {
                                          const newList = [...(formData.dosageAndAdministration || [])];
                                          newList[index].category = cat;
                                          setFormData({ ...formData, dosageAndAdministration: newList });
                                        }}
                                        className={cn(
                                          "text-[8px] font-black uppercase px-2 py-0.5 rounded-full transition-all border",
                                          item.category === cat
                                            ? "bg-blue-600 border-blue-600 text-white shadow-sm"
                                            : (isDarkMode ? "bg-slate-700 border-slate-600 text-slate-400 hover:text-blue-400 hover:border-blue-500/50" : "bg-white border-slate-200 text-slate-500 hover:text-blue-600 hover:border-blue-300")
                                        )}
                                      >
                                        {cat}
                                      </button>
                                    ))}
                                  </div>
                                  <input
                                    type="text"
                                    placeholder="Người lớn, Trẻ em..."
                                    value={item.category || ''}
                                    onChange={(e) => {
                                      const newList = [...(formData.dosageAndAdministration || [])];
                                      newList[index].category = e.target.value;
                                      setFormData({ ...formData, dosageAndAdministration: newList });
                                    }}
                                    className={cn(
                                      "w-full px-3 py-2.5 sm:py-3.5 border rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold shadow-sm transition-colors",
                                      isDarkMode ? "bg-slate-900 border-slate-700 text-slate-200" : "bg-white border-slate-200 text-slate-700"
                                    )}
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Hướng dẫn sử dụng chi tiết</label>
                                  <AutoExpandingTextarea
                                    rows={3}
                                    placeholder="Nội dung liều dùng chi tiết..."
                                    value={item.content || ''}
                                    onChange={(e) => {
                                      const newList = [...(formData.dosageAndAdministration || [])];
                                      newList[index].content = e.target.value;
                                      setFormData({ ...formData, dosageAndAdministration: newList });
                                    }}
                                    className={cn(
                                      "w-full px-3 py-2.5 sm:py-3.5 border rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none shadow-sm transition-colors",
                                      isDarkMode ? "bg-slate-900 border-slate-700 text-slate-300" : "bg-white border-slate-200"
                                    )}
                                  />
                                </div>

                                <div className={cn(
                                  "p-2 sm:p-3 rounded-xl border border-dashed transition-colors",
                                  isDarkMode ? "bg-slate-900/30 border-slate-800" : "bg-slate-50/50 border-slate-200"
                                )}>
                                  <label className="block text-[9px] font-bold text-slate-400 uppercase mb-2">Liều lượng theo cử (Sáng - Trưa - Chiều - Tối)</label>
                                  <div className="grid grid-cols-4 gap-2">
                                    {[
                                      { label: 'Sáng', key: 'morning', icon: <Zap size={12} className="text-amber-500" /> },
                                      { label: 'Trưa', key: 'noon', icon: <Star size={12} className="text-orange-500" /> },
                                      { label: 'Chiều', key: 'afternoon', icon: <Star size={12} className="text-blue-400" /> },
                                      { label: 'Tối', key: 'night', icon: <Clock size={12} className="text-indigo-500" /> }
                                    ].map((time) => (
                                      <div key={time.key}>
                                        <div className="flex items-center gap-1 mb-1 px-1">
                                          {time.icon}
                                          <span className="text-[8px] font-black uppercase text-slate-500">{time.label}</span>
                                        </div>
                                        <input
                                          type="text"
                                          placeholder="1"
                                          value={(item as any)[time.key] || ''}
                                          onChange={(e) => {
                                            const newList = [...(formData.dosageAndAdministration || [])];
                                            (newList[index] as any)[time.key] = e.target.value;
                                            setFormData({ ...formData, dosageAndAdministration: newList });
                                          }}
                                          className={cn(
                                            "w-full px-2 py-2 border rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-center shadow-sm",
                                            isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-100 text-slate-900"
                                          )}
                                        />
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </motion.div>
                  )}

                  {activeTab === 'warnings' && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }} 
                      animate={{ opacity: 1, x: 0 }}
                      className="space-y-6 sm:space-y-8"
                    >
                      {activeSubTab === 'contra' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-300 pt-2 text-rose-500">
                          <div className={cn(
                            "border rounded-2xl p-4 sm:p-6 transition-colors",
                            isDarkMode ? "bg-rose-900/10 border-rose-900/30" : "bg-rose-50/30 border-rose-100"
                          )}>
                            <div className="flex items-center justify-between mb-3 sm:mb-4">
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest flex items-center gap-2 transition-colors", isDarkMode ? "text-rose-400" : "text-rose-700")}>
                                <ShieldAlert size={16} className="sm:w-[18px] sm:h-[18px]" />
                                Chống chỉ định
                              </label>
                              <button
                                type="button"
                                onClick={() => {
                                  const newList = [...(formData.contraindications || [])];
                                  newList.push({ 
                                    content: '', 
                                    type: 'Other',
                                    ageConfig: { operator: '≤', value: '' }
                                  });
                                  setFormData({ ...formData, contraindications: newList });
                                }}
                                className={cn(
                                  "flex items-center gap-1 px-2 sm:px-3 py-1 sm:py-1.5 text-white rounded-lg text-[10px] sm:text-xs font-bold transition-all shadow-sm",
                                  isDarkMode ? "bg-rose-700 hover:bg-rose-800" : "bg-rose-600 hover:bg-rose-700"
                                )}
                              >
                                <Plus size={12} />
                                Thêm
                              </button>
                            </div>

                            <div className="space-y-2 sm:space-y-3">
                              {(formData.contraindications || []).map((contra, index) => (
                                <div key={index} className={cn(
                                  "flex gap-2 sm:gap-3 items-start p-3 sm:p-4 rounded-2xl border group relative transition-colors",
                                  isDarkMode ? "bg-slate-800 border-rose-900/20" : "bg-white border-rose-50"
                                )}>
                                  <div className="flex-1 space-y-2 sm:space-y-3">
                                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3">
                                      <div className="sm:col-span-1 space-y-1">
                                        <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Phân loại</label>
                                        <select
                                          value={contra.type || 'Other'}
                                          onChange={(e) => {
                                            const newType = e.target.value as any;
                                            const newList = [...formData.contraindications];
                                            newList[index] = { 
                                              ...newList[index], 
                                              type: newType,
                                              ageConfig: newType === 'Age' && !newList[index].ageConfig 
                                                ? { operator: '≤', value: '' } 
                                                : newList[index].ageConfig
                                            };
                                            setFormData({ ...formData, contraindications: newList });
                                          }}
                                          className={cn(
                                            "w-full px-2 sm:px-3 py-2.5 sm:py-3.5 border rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all text-xs sm:text-sm font-bold",
                                            isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-slate-50 border-slate-200"
                                          )}
                                        >
                                          <option value="Drug" className={isDarkMode ? "bg-slate-900" : "bg-white"}>Thuốc</option>
                                          <option value="ICD-10" className={isDarkMode ? "bg-slate-900" : "bg-white"}>ICD-10</option>
                                          <option value="Weight" className={isDarkMode ? "bg-slate-900" : "bg-white"}>Cân nặng</option>
                                          <option value="Age" className={isDarkMode ? "bg-slate-900" : "bg-white"}>Tuổi</option>
                                          <option value="Other" className={isDarkMode ? "bg-slate-900" : "bg-white"}>Khác</option>
                                        </select>
                                      </div>
                                      <div className="sm:col-span-2 space-y-4">
                                        <div className="space-y-1">
                                          <div className="flex items-center justify-between ml-1">
                                            <label className={cn("text-[9px] font-black uppercase tracking-widest transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                              Nội dung chống chỉ định
                                            </label>
                                          </div>
                                          <AutoExpandingTextarea
                                            rows={2}
                                            value={contra.content || ''}
                                            onChange={(e) => {
                                              const newList = [...formData.contraindications];
                                              newList[index] = { ...newList[index], content: e.target.value };
                                              setFormData({ ...formData, contraindications: newList });
                                            }}
                                            className={cn(
                                              "w-full px-3 sm:px-4 py-3 sm:py-4 border rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all text-xs sm:text-sm font-medium",
                                              isDarkMode ? "bg-slate-900 border-slate-700 text-white placeholder-slate-600" : "bg-white border-slate-200 placeholder-slate-400"
                                            )}
                                            placeholder={
                                              contra.type === 'Drug' ? "Tên thuốc tương tác ngược..." :
                                              contra.type === 'Weight' ? "Cân nặng cụ thể (VD: < 40kg)..." :
                                              contra.type === 'Age' ? "Độ tuổi (VD: Trẻ em ≤ 12 tuổi)..." :
                                              "Nhập nội dung chi tiết..."
                                            }
                                          />

                                          {contra.type === 'Age' && (
                                            <div className="mt-3 p-3 rounded-xl border border-dashed flex flex-wrap items-center gap-4 animate-in fade-in slide-in-from-top-1 duration-300"
                                              style={{ borderColor: isDarkMode ? 'rgba(244, 63, 94, 0.4)' : 'rgba(225, 29, 72, 0.2)' }}>
                                              <div className="space-y-1 w-24">
                                                <label className="text-[9px] font-black uppercase text-slate-400 tracking-wider">So sánh</label>
                                                <select
                                                  value={contra.ageConfig?.operator || '≤'}
                                                  onChange={(e) => {
                                                    const newList = [...formData.contraindications];
                                                    const ageVal = contra.ageConfig?.value || '';
                                                    const unit = contra.ageConfig?.unit || 'years';
                                                    const op = e.target.value;
                                                    newList[index] = { 
                                                      ...newList[index], 
                                                      ageConfig: { operator: op as any, value: ageVal as any, unit: unit as any },
                                                      content: ageVal !== '' ? `Tuổi ${op} ${ageVal} ${unit === 'months' ? 'tháng' : 'tuổi'}` : newList[index].content
                                                    };
                                                    setFormData({ ...formData, contraindications: newList });
                                                  }}
                                                  className={cn(
                                                    "w-full px-3 py-2.5 border rounded-lg text-xs font-bold focus:outline-none focus:ring-2 focus:ring-rose-500",
                                                    isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                                  )}
                                                >
                                                  <option value="<">{'<'}</option>
                                                  <option value=">">{'>'}</option>
                                                  <option value="≤">{'≤'}</option>
                                                  <option value="≥">{'≥'}</option>
                                                </select>
                                              </div>
                                              <div className="flex gap-2 items-end">
                                                <div className="space-y-1 w-24">
                                                  <label className="text-[9px] font-black uppercase text-slate-400 tracking-wider">Số lượng</label>
                                                  <input
                                                    type="number"
                                                    value={contra.ageConfig?.value || ''}
                                                    onChange={(e) => {
                                                      const valStr = e.target.value;
                                                      const val = valStr === '' ? '' : parseInt(valStr);
                                                      const newList = [...formData.contraindications];
                                                      const op = contra.ageConfig?.operator || '≤';
                                                      const unit = contra.ageConfig?.unit || 'years';
                                                      newList[index] = { 
                                                        ...newList[index], 
                                                        ageConfig: { operator: op as any, value: val as any, unit: unit as any },
                                                        content: val !== '' ? `Tuổi ${op} ${val} ${unit === 'months' ? 'tháng' : 'tuổi'}` : newList[index].content
                                                      };
                                                      setFormData({ ...formData, contraindications: newList });
                                                    }}
                                                    placeholder="VD: 12"
                                                    className={cn(
                                                      "w-full px-3 py-2.5 border rounded-lg text-xs font-bold focus:outline-none focus:ring-2 focus:ring-rose-500",
                                                      isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                                    )}
                                                  />
                                                </div>
                                                <div className="space-y-1">
                                                  <select
                                                    value={contra.ageConfig?.unit || 'years'}
                                                    onChange={(e) => {
                                                      const unit = e.target.value as 'years' | 'months';
                                                      const newList = [...formData.contraindications];
                                                      const op = contra.ageConfig?.operator || '≤';
                                                      const val = contra.ageConfig?.value || '';
                                                      newList[index] = { 
                                                        ...newList[index], 
                                                        ageConfig: { operator: op as any, value: val as any, unit },
                                                        content: val !== '' ? `Tuổi ${op} ${val} ${unit === 'months' ? 'tháng' : 'tuổi'}` : newList[index].content
                                                      };
                                                      setFormData({ ...formData, contraindications: newList });
                                                    }}
                                                    className={cn(
                                                      "px-2 py-2.5 border rounded-lg text-[10px] font-black uppercase tracking-wider focus:outline-none focus:ring-2 focus:ring-rose-500",
                                                      isDarkMode ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200"
                                                    )}
                                                  >
                                                    <option value="years">Tuổi (Năm)</option>
                                                    <option value="months">Tháng</option>
                                                  </select>
                                                </div>
                                              </div>
                                              {typeof contra.ageConfig?.value === 'number' && (
                                                <div className="flex-1 space-y-1">
                                                  <label className="text-[9px] font-black uppercase text-slate-400 tracking-wider">Mốc sinh (Gợi ý)</label>
                                                  <div className={cn(
                                                    "flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-black border",
                                                    isDarkMode 
                                                      ? "bg-rose-500/10 border-rose-500/20 text-rose-400" 
                                                      : "bg-rose-50 border-rose-100 text-rose-600 shadow-sm"
                                                  )}>
                                                    <Calendar size={12} className="shrink-0" />
                                                    <span>
                                                      {(() => {
                                                        const d = new Date();
                                                        if (contra.ageConfig.unit === 'months') {
                                                          d.setMonth(d.getMonth() - contra.ageConfig.value);
                                                        } else {
                                                          d.setFullYear(d.getFullYear() - contra.ageConfig.value);
                                                        }
                                                        return d.toLocaleDateString('vi-VN');
                                                      })()}
                                                    </span>
                                                    <span className="opacity-50 text-[10px] font-medium">(Nay: {new Date().toLocaleDateString('vi-VN')})</span>
                                                  </div>
                                                </div>
                                              )}
                                            </div>
                                          )}
                                        </div>

                                        <div className="space-y-1">
                                          <div className="flex items-center justify-between ml-1">
                                            <label className={cn("text-[9px] font-black uppercase tracking-widest transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                                              {contra.type === 'ICD-10' ? "Mã ICD-10 gợi ý" : ""}
                                            </label>
                                            {contra.type === 'ICD-10' && (
                                              <button
                                                type="button"
                                                onClick={() => {
                                                  setIcdLookupTarget({ type: 'contraindication', index });
                                                  setIsIcdLookupOpen(true);
                                                }}
                                                className={cn(
                                                  "text-[9px] font-black uppercase tracking-widest flex items-center gap-1 transition-colors",
                                                  isDarkMode ? "text-blue-400 hover:text-blue-300" : "text-blue-600 hover:text-blue-700"
                                                )}
                                              >
                                                <Database size={10} />
                                                Tra cứu ICD-10
                                              </button>
                                            )}
                                          </div>

                                          {contra.type === 'ICD-10' && (
                                            <>
                                              <div className="flex flex-wrap gap-1 mb-2">
                                                {(contra.icd10s || []).map((code, tagIdx) => (
                                                  <div 
                                                    key={tagIdx} 
                                                    className={cn(
                                                      "inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold border animate-in fade-in zoom-in duration-200 transition-all",
                                                      isDarkMode ? "bg-rose-500/10 text-rose-400 border-rose-500/20" : "bg-rose-50 text-rose-600 border-rose-100"
                                                    )}
                                                  >
                                                    {code.split(' - ')[0]}
                                                    <button
                                                      type="button"
                                                      onClick={() => {
                                                        const newList = [...formData.contraindications];
                                                        newList[index] = {
                                                          ...newList[index],
                                                          icd10s: (newList[index].icd10s || []).filter((_, i) => i !== tagIdx)
                                                        };
                                                        setFormData({ ...formData, contraindications: newList });
                                                      }}
                                                      className="hover:text-rose-500 transition-colors"
                                                    >
                                                      <X size={10} />
                                                    </button>
                                                  </div>
                                                ))}
                                              </div>

                                              <div className="relative">
                                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={12} />
                                                <input
                                                  type="text"
                                                  value={searchingContraIcdIndex === index ? icdQuery : ''}
                                                  onFocus={() => {
                                                    setSearchingContraIcdIndex(index);
                                                    setIcdQuery('');
                                                  }}
                                                  onChange={(e) => {
                                                    setIcdQuery(e.target.value);
                                                    setSearchingContraIcdIndex(index);
                                                  }}
                                                  onBlur={() => {
                                                    setTimeout(() => setSearchingContraIcdIndex(null), 200);
                                                  }}
                                                  className={cn(
                                                    "w-full px-3 sm:px-4 py-2 border rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all text-[11px] sm:text-xs font-medium pl-8 sm:pl-9",
                                                    isDarkMode ? "bg-slate-900 border-slate-700 text-white placeholder-slate-600" : "bg-white border-slate-200 placeholder-slate-400"
                                                  )}
                                                  placeholder="Tìm nhanh mã ICD-10 để gán..."
                                                />
                                                {searchingContraIcdIndex === index && icdQuery && (
                                                  <div className={cn(
                                                    "absolute left-0 right-0 top-full mt-1 z-50 rounded-xl border shadow-xl max-h-48 overflow-y-auto overflow-x-hidden",
                                                    isDarkMode ? "bg-slate-900 border-slate-700" : "bg-white border-slate-200"
                                                  )}>
                                                    {icdList
                                                      .filter(icd => (icd.code || '').toLowerCase().includes(icdQuery.toLowerCase()) || (icd.description || '').toLowerCase().includes(icdQuery.toLowerCase()))
                                                      .slice(0, 50)
                                                      .map((icd, icdIdx) => (
                                                        <button
                                                          key={icdIdx}
                                                          type="button"
                                                          onClick={() => {
                                                            const newList = [...formData.contraindications];
                                                            const currentIcd10s = newList[index].icd10s || [];
                                                            const fullCode = `${icd.code} - ${icd.description}`;
                                                            if (!currentIcd10s.includes(fullCode)) {
                                                              newList[index] = {
                                                                ...newList[index],
                                                                icd10s: [...currentIcd10s, fullCode]
                                                              };
                                                              setFormData({ ...formData, contraindications: newList });
                                                            }
                                                            setIcdQuery('');
                                                            setSearchingContraIcdIndex(null);
                                                          }}
                                                          className={cn(
                                                            "w-full text-left px-3 sm:px-4 py-2 text-[10px] sm:text-xs hover:bg-rose-500 hover:text-white transition-colors border-b last:border-b-0",
                                                            isDarkMode ? "border-slate-800" : "border-slate-100"
                                                          )}
                                                        >
                                                          <span className="font-bold">{icd.code}</span> - {icd.description}
                                                        </button>
                                                      ))}
                                                  </div>
                                                )}
                                              </div>
                                            </>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex flex-col gap-1 mt-5 sm:mt-6">
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('contraindications', index, 'up')}
                                      disabled={index === 0}
                                      className={cn(
                                        "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                        index === 0 ? "invisible" : (isDarkMode ? "text-slate-500 hover:text-blue-400 hover:bg-blue-900/20" : "text-slate-400 hover:text-blue-600 hover:bg-blue-50")
                                      )}
                                    >
                                      <ChevronUp size={14} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('contraindications', index, 'down')}
                                      disabled={index === formData.contraindications.length - 1}
                                      className={cn(
                                        "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                        index === formData.contraindications.length - 1 ? "invisible" : (isDarkMode ? "text-slate-500 hover:text-blue-400 hover:bg-blue-900/20" : "text-slate-400 hover:text-blue-600 hover:bg-blue-50")
                                      )}
                                    >
                                      <ChevronDown size={14} />
                                    </button>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newList = formData.contraindications.filter((_, i) => i !== index);
                                      setFormData({ ...formData, contraindications: newList });
                                    }}
                                    className={cn(
                                      "mt-5 sm:mt-6 p-1.5 sm:p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100",
                                      isDarkMode ? "text-slate-500 hover:text-rose-400 hover:bg-rose-900/20" : "text-slate-400 hover:text-rose-500 hover:bg-rose-50"
                                    )}
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {activeSubTab === 'adr' && (
                        <div className="pt-2 sm:pt-4 animate-in fade-in slide-in-from-right-4 duration-300">
                          <div className="flex items-center justify-between mb-3 sm:mb-4">
                            <label className={cn("block text-[10px] sm:text-xs font-black uppercase tracking-widest flex items-center gap-2", isDarkMode ? "text-amber-400" : "text-amber-700")}>
                              <Info size={16} />
                              Tác dụng không mong muốn (ADR)
                            </label>
                            <button
                              type="button"
                              onClick={() => {
                                const current = (Array.isArray(formData.sideEffects) ? formData.sideEffects : []) as any[];
                                setFormData({
                                  ...formData,
                                  sideEffects: [...current, { frequency: '', content: '' }]
                                });
                              }}
                              className={cn(
                                "text-[10px] sm:text-xs px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg font-bold transition-all flex items-center gap-1",
                                isDarkMode ? "bg-amber-900/30 text-amber-400 hover:bg-amber-900/50" : "bg-amber-50 text-amber-600 hover:bg-amber-100"
                              )}
                            >
                              <Plus size={12} /> Thêm nhóm
                            </button>
                          </div>
                          
                          <div className="space-y-4">
                            {(Array.isArray(formData.sideEffects) ? (formData.sideEffects as any[]) : []).map((se, index) => (
                              <div key={index} className={cn(
                                "p-4 rounded-2xl border shadow-sm space-y-3 relative group transition-colors",
                                isDarkMode ? "bg-slate-800 border-slate-700" : "bg-white border-slate-200"
                              )}>
                                <div className="flex flex-col gap-1 absolute top-3 right-10">
                                  <button
                                    type="button"
                                    onClick={() => moveArrayItem('sideEffects', index, 'up')}
                                    disabled={index === 0}
                                    className={cn(
                                      "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                      index === 0 ? "invisible" : (isDarkMode ? "text-slate-500 hover:text-blue-400 hover:bg-blue-900/20" : "text-slate-400 hover:text-blue-600 hover:bg-blue-50")
                                    )}
                                  >
                                    <ChevronUp size={14} />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => moveArrayItem('sideEffects', index, 'down')}
                                    disabled={index === (formData.sideEffects as any[]).length - 1}
                                    className={cn(
                                      "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                      index === (formData.sideEffects as any[]).length - 1 ? "invisible" : (isDarkMode ? "text-slate-500 hover:text-blue-400 hover:bg-blue-900/20" : "text-slate-400 hover:text-blue-600 hover:bg-blue-50")
                                    )}
                                  >
                                    <ChevronDown size={14} />
                                  </button>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const newList = [...(formData.sideEffects as any[])];
                                    newList.splice(index, 1);
                                    setFormData({ ...formData, sideEffects: newList });
                                  }}
                                  className={cn(
                                    "absolute top-3 right-3 p-1.5 text-slate-400 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100 rounded-lg",
                                    isDarkMode ? "hover:bg-rose-900/20" : "hover:bg-rose-50"
                                  )}
                                >
                                  <X size={14} />
                                </button>
                                
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                  <div className="sm:col-span-1">
                                    <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Tần suất</label>
                                    <select
                                      value={se.frequency || ''}
                                      onChange={(e) => {
                                        const newList = [...(formData.sideEffects as any[])];
                                        newList[index] = { ...newList[index], frequency: e.target.value };
                                        setFormData({ ...formData, sideEffects: newList });
                                      }}
                                      className={cn(
                                        "w-full px-3 py-2.5 sm:py-3.5 border rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 font-bold transition-colors",
                                        isDarkMode ? "bg-slate-900 border-slate-700 text-slate-300" : "bg-slate-50 border-slate-200"
                                      )}
                                    >
                                      <option value="">-- Chọn tần suất --</option>
                                      <option value="Thường gặp (ADR > 1/100)">Thường gặp (&gt;1/100)</option>
                                      <option value="Ít gặp (1/1000 < ADR < 1/100)">Ít gặp (1/1000 - 1/100)</option>
                                      <option value="Hiếm gặp (ADR < 1/1000)">Hiếm gặp (&lt;1/1000)</option>
                                      <option value="Rất hiếm gặp (ADR < 1/10000)">Rất hiếm gặp</option>
                                      <option value="Chưa xác định">Chưa xác định</option>
                                    </select>
                                  </div>
                                  <div className="sm:col-span-2">
                                    <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Nội dung tác dụng phụ</label>
                                    <AutoExpandingTextarea
                                      rows={4}
                                      value={se.content || ''}
                                      onChange={(e) => {
                                        const newList = [...(formData.sideEffects as any[])];
                                        newList[index] = { ...newList[index], content: e.target.value };
                                        setFormData({ ...formData, sideEffects: newList });
                                      }}
                                      placeholder="Rối loạn tiêu hóa, nhức đầu..."
                                      className={cn(
                                        "w-full px-4 py-3 sm:py-4 border rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all resize-none text-xs sm:text-sm font-medium",
                                        isDarkMode ? "bg-slate-900 border-slate-700 text-slate-300" : "bg-slate-50 border-slate-200"
                                      )}
                                    />
                                  </div>
                                </div>
                              </div>
                            ))}
                            {(Array.isArray(formData.sideEffects) ? (formData.sideEffects as any[]) : []).length === 0 && (
                              <div className={cn(
                                "flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-3xl",
                                isDarkMode ? "border-slate-800 text-slate-500" : "border-slate-100 text-slate-400"
                              )}>
                                <Info size={32} className="mb-2 opacity-20" />
                                <p className="text-sm font-medium italic">Chưa có thông tin tác dụng phụ theo nhóm. Nhấn "Thêm nhóm" để bắt đầu.</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {activeSubTab === 'special' && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 animate-in fade-in slide-in-from-right-4 duration-300">
                          {[
                            { label: 'Thận trọng', key: 'precautions', icon: <ShieldAlert size={14} />, color: 'amber', type: 'textarea' },
                            { label: 'Phụ nữ có thai', key: 'pregnancy', icon: <Heart size={14} />, color: 'rose', type: 'select', options: ['An toàn', 'Chưa thiết lập', 'Cân nhắc lợi ích', 'Không an toàn'] },
                            { label: 'Phụ nữ cho con bú', key: 'lactation', icon: <Baby size={14} />, color: 'pink', type: 'select', options: ['An toàn', 'Chưa thiết lập', 'Cân nhắc lợi ích', 'Không an toàn'] },
                            { label: 'Vận hành máy móc', key: 'driving', icon: <Car size={14} />, color: 'slate', type: 'select', options: ['An toàn', 'Không an toàn'] },
                            { label: 'Quá liều - Xử trí', key: 'overdose', icon: <AlertTriangle size={14} />, color: 'red', type: 'textarea' },
                          ].map((field) => (
                            <div key={field.key} className={field.type === 'textarea' ? 'sm:col-span-2' : ''}>
                              <label className={cn(`block text-[10px] sm:text-xs font-black uppercase tracking-widest mb-1.5 flex items-center gap-2`, isDarkMode ? `text-${field.color}-400` : `text-${field.color}-700`)}>
                                {field.icon}
                                {field.label}
                              </label>
                              {field.type === 'select' ? (
                                <select
                                  value={(formData as any)[field.key] || (field.options ? field.options[0] : '')}
                                  onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                                  className={cn(
                                    `w-full px-3 py-3 sm:py-4 border rounded-xl focus:outline-none focus:ring-2 focus:ring-${field.color}-500 transition-all text-xs sm:text-sm font-bold`,
                                    isDarkMode ? "bg-slate-900 border-slate-700 text-slate-300" : `bg-${field.color}-50/30 border-${field.color}-100`
                                  )}
                                >
                                  {field.options?.map(opt => (
                                    <option key={opt} value={opt} className={isDarkMode ? "bg-slate-900" : "bg-white"}>{opt}</option>
                                  ))}
                                </select>
                              ) : (
                                <AutoExpandingTextarea
                                  rows={5}
                                  value={(formData as any)[field.key] || ''}
                                  onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                                  className={cn(
                                    `w-full px-3 py-3 sm:py-4 border rounded-xl focus:outline-none focus:ring-2 focus:ring-${field.color}-500 transition-all resize-none text-xs sm:text-sm font-medium`,
                                    isDarkMode ? "bg-slate-900 border-slate-700 text-slate-300" : `bg-${field.color}-50/30 border-${field.color}-100`
                                  )}
                                />
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </motion.div>
                  )}

                  {activeTab === 'pharmacology' && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }} 
                      animate={{ opacity: 1, x: 0 }}
                      className="space-y-6 sm:space-y-8"
                    >
                      {activeSubTab === 'interactions' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-300">
                          {/* Tương tác cụ thể */}
                          <div className={cn(
                            "p-4 sm:p-6 rounded-2xl border transition-colors",
                            isDarkMode ? "bg-indigo-900/10 border-indigo-900/20" : "bg-indigo-50/30 border-indigo-100"
                          )}>
                            <div className="flex items-center justify-between mb-4">
                              <label className={cn("block text-[10px] sm:text-sm font-black uppercase tracking-widest flex items-center gap-2 transition-colors", isDarkMode ? "text-indigo-400" : "text-indigo-700")}>
                                <Zap size={16} className="sm:w-[18px] sm:h-[18px]" />
                                Tương tác thuốc cụ thể
                              </label>
                              <button
                                type="button"
                                onClick={() => {
                                  const newList = [...(formData.specificInteractions || [])];
                                  newList.push({ target: '', content: '' });
                                  setFormData({ ...formData, specificInteractions: newList });
                                }}
                                className={cn(
                                  "flex items-center gap-1 text-[10px] sm:text-xs font-bold px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg transition-all",
                                  isDarkMode ? "text-indigo-400 bg-indigo-900/30 hover:bg-indigo-900/50" : "text-indigo-600 bg-indigo-50 hover:bg-indigo-100"
                                )}
                              >
                                <Plus size={12} /> Thêm
                              </button>
                            </div>
                            <div className="space-y-2 sm:space-y-3">
                              {(formData.specificInteractions || []).map((item, index) => (
                                <div key={index} className={cn(
                                  "p-3 sm:p-4 rounded-2xl border shadow-sm space-y-2 sm:space-y-3 relative group transition-colors",
                                  isDarkMode ? "bg-slate-800 border-slate-700" : "bg-white border-slate-200"
                                )}>
                                  <div className="flex flex-col gap-1 absolute top-3 sm:top-4 right-10 sm:right-12">
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('specificInteractions', index, 'up')}
                                      disabled={index === 0}
                                      className={cn(
                                        "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                        index === 0 ? "invisible" : (isDarkMode ? "text-slate-600 hover:text-indigo-400 hover:bg-slate-700" : "text-slate-300 hover:text-indigo-600 hover:bg-slate-50")
                                      )}
                                    >
                                      <ChevronUp size={16} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('specificInteractions', index, 'down')}
                                      disabled={index === (formData.specificInteractions || []).length - 1}
                                      className={cn(
                                        "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                        index === (formData.specificInteractions || []).length - 1 ? "invisible" : (isDarkMode ? "text-slate-600 hover:text-indigo-400 hover:bg-slate-700" : "text-slate-300 hover:text-indigo-600 hover:bg-slate-50")
                                      )}
                                    >
                                      <ChevronDown size={16} />
                                    </button>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newList = (formData.specificInteractions || []).filter((_, i) => i !== index);
                                      setFormData({ ...formData, specificInteractions: newList });
                                    }}
                                    className={cn(
                                      "absolute top-3 sm:top-4 right-3 sm:right-4 p-1.5 sm:p-2 transition-all opacity-0 group-hover:opacity-100 rounded-lg",
                                      isDarkMode ? "text-slate-600 hover:text-red-400 hover:bg-red-900/20" : "text-slate-300 hover:text-red-500 hover:bg-red-50"
                                    )}
                                  >
                                    <Trash2 size={16} />
                                  </button>
                                  <div className="w-full">
                                    <label className={cn("block text-[9px] font-bold uppercase mb-1 transition-colors", isDarkMode ? "text-slate-500" : "text-slate-400")}>Đối tượng tương tác</label>
                                    <input
                                      type="text"
                                      value={item.target || ''}
                                      onChange={(e) => {
                                        const newList = [...(formData.specificInteractions || [])];
                                        newList[index].target = e.target.value;
                                        setFormData({ ...formData, specificInteractions: newList });
                                      }}
                                      className={cn(
                                        "w-full px-3 py-2.5 sm:py-3.5 border rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold transition-colors",
                                        isDarkMode ? "bg-slate-900 border-slate-700 text-slate-200" : "bg-slate-50 border-slate-200 text-slate-700"
                                      )}
                                      placeholder="Ví dụ: Simvastatin..."
                                    />
                                  </div>
                                  <div>
                                    <label className={cn("block text-[9px] font-bold uppercase mb-1 transition-colors", isDarkMode ? "text-slate-500" : "text-slate-400")}>Nội dung tương tác</label>
                                    <AutoExpandingTextarea
                                      rows={4}
                                      value={item.content || ''}
                                      onChange={(e) => {
                                        const newList = [...(formData.specificInteractions || [])];
                                        newList[index].content = e.target.value;
                                        setFormData({ ...formData, specificInteractions: newList });
                                      }}
                                      className={cn(
                                        "w-full px-3 py-2.5 sm:py-3.5 border rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none transition-colors",
                                        isDarkMode ? "bg-slate-900 border-slate-700 text-slate-300" : "bg-slate-50 border-slate-200"
                                      )}
                                    />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Tương tác chung */}
                          <div>
                            <label className={cn("block text-[10px] sm:text-xs font-black uppercase tracking-widest mb-2 flex items-center gap-2 transition-colors", isDarkMode ? "text-indigo-400" : "text-indigo-700")}>
                              <RefreshCw size={16} />
                              Tương tác chung
                            </label>
                            <AutoExpandingTextarea
                              rows={5}
                              value={formData.interactions || ''}
                              onChange={(e) => setFormData({ ...formData, interactions: e.target.value })}
                              className={cn(
                                "w-full px-3 sm:px-4 py-3 sm:py-4 border rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 transition-all resize-none font-medium",
                                isDarkMode ? "bg-slate-900 border-slate-700 text-slate-300 focus:ring-indigo-900/50" : "bg-indigo-50/30 border-indigo-100 focus:ring-indigo-500"
                              )}
                              placeholder="Nhập các tương tác thuốc chung..."
                            />
                          </div>
                        </div>
                      )}

                      {activeSubTab === 'properties' && (
                        <div className="space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                          {/* Dược lực học */}
                          <div className={cn(
                            "p-4 sm:p-6 rounded-2xl border transition-colors",
                            isDarkMode ? "bg-emerald-900/10 border-emerald-900/20" : "bg-emerald-50/30 border-emerald-100"
                          )}>
                            <div className="flex items-center justify-between mb-4">
                              <label className={cn("block text-[10px] sm:text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-colors", isDarkMode ? "text-emerald-400" : "text-emerald-700")}>
                                <Activity size={16} />
                                Dược lực học
                              </label>
                              <button
                                type="button"
                                onClick={() => setFormData({ ...formData, pharmacodynamics: [...(Array.isArray(formData.pharmacodynamics) ? formData.pharmacodynamics : []), { category: '', content: '' }] })}
                                className={cn(
                                  "text-[10px] font-black uppercase transition-colors flex items-center gap-1",
                                  isDarkMode ? "text-emerald-400 hover:text-emerald-300" : "text-emerald-600 hover:text-emerald-700"
                                )}
                              >
                                <Plus size={14} /> Thêm phân loại
                              </button>
                            </div>
                            <div className="space-y-3">
                              {(Array.isArray(formData.pharmacodynamics) ? formData.pharmacodynamics : []).map((item: any, idx) => (
                                <div key={idx} className={cn(
                                  "p-4 rounded-2xl border transition-all relative group shadow-sm",
                                  isDarkMode ? "bg-slate-900 border-slate-800" : "bg-emerald-50/30 border-emerald-100/50"
                                )}>
                                  <div className="flex flex-col gap-1 absolute top-2 right-8">
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('pharmacodynamics', idx, 'up')}
                                      disabled={idx === 0}
                                      className={cn(
                                        "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                        idx === 0 ? "invisible" : (isDarkMode ? "text-emerald-400 hover:text-emerald-300" : "text-emerald-400 hover:text-emerald-600")
                                      )}
                                    >
                                      <ChevronUp size={14} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('pharmacodynamics', idx, 'down')}
                                      disabled={idx === (formData.pharmacodynamics as any[]).length - 1}
                                      className={cn(
                                        "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                        idx === (formData.pharmacodynamics as any[]).length - 1 ? "invisible" : (isDarkMode ? "text-emerald-400 hover:text-emerald-300" : "text-emerald-400 hover:text-emerald-600")
                                      )}
                                    >
                                      <ChevronDown size={14} />
                                    </button>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newList = [...(formData.pharmacodynamics as any[])];
                                      newList.splice(idx, 1);
                                      setFormData({ ...formData, pharmacodynamics: newList });
                                    }}
                                    className="absolute top-2 right-2 p-1 text-slate-400 hover:text-rose-500 transition-colors"
                                  >
                                    <X size={14} />
                                  </button>
                                  <input
                                    type="text"
                                    placeholder="Phân loại (Ví dụ: Cơ chế tác dụng, Tác động lâm sàng...)"
                                    value={item.category}
                                    onChange={(e) => {
                                      const newList = [...(formData.pharmacodynamics as any[])];
                                      newList[idx].category = e.target.value;
                                      setFormData({ ...formData, pharmacodynamics: newList });
                                    }}
                                    className={cn(
                                      "w-full mb-2 bg-transparent border-none p-0 text-[10px] font-black uppercase tracking-wider focus:ring-0 placeholder:text-slate-500",
                                      isDarkMode ? "text-emerald-400" : "text-emerald-600"
                                    )}
                                  />
                                  <AutoExpandingTextarea
                                    rows={4}
                                    placeholder="Nội dung chi tiết cho phân loại này..."
                                    value={item.content}
                                    onChange={(e) => {
                                      const newList = [...(formData.pharmacodynamics as any[])];
                                      newList[idx].content = e.target.value;
                                      setFormData({ ...formData, pharmacodynamics: newList });
                                    }}
                                    className={cn(
                                      "w-full bg-transparent border-none p-0 text-xs sm:text-sm focus:ring-0 resize-none font-medium",
                                      isDarkMode ? "text-slate-300 placeholder:text-slate-700" : "text-slate-700 placeholder:text-slate-400"
                                    )}
                                  />
                                </div>
                              ))}
                              {(Array.isArray(formData.pharmacodynamics) ? formData.pharmacodynamics : []).length === 0 && (
                                <p className="text-[10px] text-slate-500 italic text-center py-2">Chưa có phân loại dược lực học nào.</p>
                              )}
                            </div>
                          </div>

                          {/* Dược động học */}
                          <div className={cn(
                            "p-4 sm:p-6 rounded-2xl border transition-colors",
                            isDarkMode ? "bg-blue-900/10 border-blue-900/20" : "bg-blue-50/30 border-blue-100"
                          )}>
                            <div className="flex items-center justify-between mb-4">
                              <label className={cn("block text-[10px] sm:text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-colors", isDarkMode ? "text-blue-400" : "text-blue-700")}>
                                <MoveRight size={16} />
                                Dược động học
                              </label>
                              <button
                                type="button"
                                onClick={() => setFormData({ ...formData, pharmacokinetics: [...(Array.isArray(formData.pharmacokinetics) ? formData.pharmacokinetics : []), { category: '', content: '' }] })}
                                className={cn(
                                  "text-[10px] font-black uppercase transition-colors flex items-center gap-1",
                                  isDarkMode ? "text-blue-400 hover:text-blue-300" : "text-blue-600 hover:text-blue-700"
                                )}
                              >
                                <Plus size={14} /> Thêm phân loại
                              </button>
                            </div>
                            <div className="space-y-3">
                              {(Array.isArray(formData.pharmacokinetics) ? formData.pharmacokinetics : []).map((item: any, idx) => (
                                <div key={idx} className={cn(
                                  "p-4 rounded-2xl border transition-all relative group shadow-sm",
                                  isDarkMode ? "bg-slate-900 border-slate-800" : "bg-blue-50/30 border-blue-100/50"
                                )}>
                                  <div className="flex flex-col gap-1 absolute top-2 right-8">
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('pharmacokinetics', idx, 'up')}
                                      disabled={idx === 0}
                                      className={cn(
                                        "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                        idx === 0 ? "invisible" : (isDarkMode ? "text-blue-400 hover:text-blue-300" : "text-blue-400 hover:text-blue-600")
                                      )}
                                    >
                                      <ChevronUp size={14} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => moveArrayItem('pharmacokinetics', idx, 'down')}
                                      disabled={idx === (formData.pharmacokinetics as any[]).length - 1}
                                      className={cn(
                                        "p-1 rounded-md transition-all opacity-0 group-hover:opacity-100",
                                        idx === (formData.pharmacokinetics as any[]).length - 1 ? "invisible" : (isDarkMode ? "text-blue-400 hover:text-blue-300" : "text-blue-400 hover:text-blue-600")
                                      )}
                                    >
                                      <ChevronDown size={14} />
                                    </button>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newList = [...(formData.pharmacokinetics as any[])];
                                      newList.splice(idx, 1);
                                      setFormData({ ...formData, pharmacokinetics: newList });
                                    }}
                                    className="absolute top-2 right-2 p-1 text-slate-400 hover:text-rose-500 transition-colors"
                                  >
                                    <X size={14} />
                                  </button>
                                  <input
                                    type="text"
                                    placeholder="Phân loại (Ví dụ: Hấp thu, Phân bố, Chuyển hóa, Thải trừ...)"
                                    value={item.category}
                                    onChange={(e) => {
                                      const newList = [...(formData.pharmacokinetics as any[])];
                                      newList[idx].category = e.target.value;
                                      setFormData({ ...formData, pharmacokinetics: newList });
                                    }}
                                    className={cn(
                                      "w-full mb-2 bg-transparent border-none p-0 text-[10px] font-black uppercase tracking-wider focus:ring-0 placeholder:text-slate-500",
                                      isDarkMode ? "text-blue-400" : "text-blue-600"
                                    )}
                                  />
                                  <AutoExpandingTextarea
                                    rows={4}
                                    placeholder="Nội dung chi tiết cho phân loại này..."
                                    value={item.content}
                                    onChange={(e) => {
                                      const newList = [...(formData.pharmacokinetics as any[])];
                                      newList[idx].content = e.target.value;
                                      setFormData({ ...formData, pharmacokinetics: newList });
                                    }}
                                    className={cn(
                                      "w-full bg-transparent border-none p-0 text-xs sm:text-sm focus:ring-0 resize-none font-medium",
                                      isDarkMode ? "text-slate-300 placeholder:text-slate-700" : "text-slate-700 placeholder:text-slate-400"
                                    )}
                                  />
                                </div>
                              ))}
                              {(Array.isArray(formData.pharmacokinetics) ? formData.pharmacokinetics : []).length === 0 && (
                                <p className="text-[10px] text-slate-500 italic text-center py-2">Chưa có phân loại dược động học nào.</p>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  )}
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* AI Review Modal */}
      <AnimatePresence>
        {isReviewModalOpen && extractedData && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={cn(
                "relative w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden max-h-[85vh] flex flex-col border transition-colors",
                isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
              )}
            >
              <div className={cn(
                "p-6 border-b flex items-center justify-between transition-colors",
                isDarkMode ? "border-slate-800 bg-indigo-900/10" : "border-slate-100 bg-indigo-50/50"
              )}>
                <div className="flex items-center gap-3">
                  <div className="bg-indigo-600 p-2 rounded-lg text-white">
                    <FileText size={20} />
                  </div>
                  <h3 className={cn("text-xl font-bold transition-colors", isDarkMode ? "text-white" : "text-slate-900")}>Xác nhận thông tin trích xuất</h3>
                </div>
                <button 
                  type="button"
                  onClick={() => setIsReviewModalOpen(false)} 
                  className={cn("p-2 rounded-full transition-colors", isDarkMode ? "hover:bg-slate-800" : "hover:bg-slate-200")}
                >
                  <X size={20} className={isDarkMode ? "text-slate-400" : ""} />
                </button>
              </div>

              <div className="p-8 overflow-y-auto space-y-6 transition-colors">
                <div className={cn(
                  "flex items-center gap-4 p-6 rounded-[24px] border transition-colors",
                  isDarkMode ? "bg-indigo-900/20 border-indigo-900/30" : "bg-indigo-50 border-indigo-100"
                )}>
                  <div className={cn(
                    "w-16 h-16 rounded-2xl flex items-center justify-center shadow-sm shrink-0 transition-colors",
                    isDarkMode ? "bg-slate-800" : "bg-white"
                  )}>
                    <Check className={isDarkMode ? "text-indigo-400" : "text-indigo-600"} size={32} />
                  </div>
                  <div>
                    <h4 className={cn("text-lg font-black transition-colors", isDarkMode ? "text-white" : "text-slate-900")}>Trích xuất thành công!</h4>
                    <p className={cn("text-sm font-medium transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>AI đã phân tích tài liệu và tìm thấy các thông tin quan trọng.</p>
                  </div>
                </div>
                
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        { label: 'Tên thuốc', value: extractedData.name, icon: <Pill size={16} /> },
                        { label: 'Hoạt chất', value: (extractedData.activeIngredients?.[0]?.name || (typeof extractedData.activeIngredients?.[0] === 'string' ? extractedData.activeIngredients[0] : '') || 'N/A') as string, icon: <Activity size={16} /> },
                        { label: 'Chỉ định', value: `${(extractedData.indications || []).length} mục`, icon: <Info size={16} /> },
                        { label: 'Liều dùng', value: `${(extractedData.dosageAndAdministration || []).length} đối tượng`, icon: <Clock size={16} /> },
                      ].map((field, idx) => (
                        <div key={idx} className={cn(
                          "p-4 rounded-2xl border flex items-center gap-3 transition-colors",
                          isDarkMode ? "border-slate-800 bg-slate-800/50" : "border-slate-100 bg-slate-50/50"
                        )}>
                          <div className={cn(
                            "w-8 h-8 rounded-lg flex items-center justify-center shadow-sm transition-colors",
                            isDarkMode ? "bg-slate-700 text-slate-500" : "bg-white text-slate-400"
                          )}>
                            {field.icon}
                          </div>
                          <div>
                            <span className={cn("text-[10px] font-black uppercase tracking-widest block transition-colors", isDarkMode ? "text-slate-500" : "text-slate-400")}>{field.label}</span>
                            <p className={cn("text-sm font-bold truncate transition-colors", isDarkMode ? "text-slate-300" : "text-slate-700")}>{field.value || '(Trống)'}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                <div className={cn(
                  "p-5 rounded-2xl border transition-colors",
                  isDarkMode ? "bg-amber-900/10 border-amber-900/30" : "bg-amber-50/50 border-amber-100/50"
                )}>
                  <div className={cn("flex items-center gap-2 mb-2 transition-colors", isDarkMode ? "text-amber-400" : "text-amber-600")}>
                    <ShieldAlert size={16} />
                    <span className="text-[10px] font-black uppercase tracking-widest">Lưu ý quan trọng</span>
                  </div>
                  <p className={cn("text-xs leading-relaxed font-medium transition-colors", isDarkMode ? "text-amber-300" : "text-amber-700")}>
                    Tất cả các trường thông tin khác (Chống chỉ định, Tác dụng phụ, Thận trọng, Tương tác...) cũng đã được trích xuất và sẽ tự động điền vào biểu mẫu. Vui lòng kiểm tra lại kỹ trước khi lưu.
                  </p>
                </div>
              </div>

              <div className={cn(
                "p-6 border-t flex gap-3 transition-colors",
                isDarkMode ? "border-slate-800" : "border-slate-100"
              )}>
                <button
                  type="button"
                  onClick={() => setIsReviewModalOpen(false)}
                  className={cn(
                    "flex-1 py-3 rounded-xl font-bold transition-all",
                    isDarkMode ? "bg-slate-800 text-slate-400 hover:bg-slate-700" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  )}
                >
                  Bỏ qua
                </button>
                <button
                  type="button"
                  onClick={applyExtractedData}
                  className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                >
                  <Save size={18} /> Áp dụng thay đổi
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {pdfViewerUrl && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setPdfViewerUrl(null)}
              className="absolute inset-0 bg-slate-900/80 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={cn(
                "relative w-full max-w-5xl h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col border transition-colors",
                isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
              )}
            >
              <div className={cn(
                "p-4 border-b flex items-center justify-between transition-colors",
                isDarkMode ? "border-slate-800 bg-slate-900" : "border-slate-100 bg-white"
              )}>
                <div className="flex items-center gap-3">
                  <FileText className={isDarkMode ? "text-blue-400" : "text-blue-600"} size={24} />
                  <h3 className={cn("font-bold transition-colors", isDarkMode ? "text-white" : "text-slate-900")}>Tài liệu hướng dẫn thuốc</h3>
                </div>
                <div className="flex items-center gap-2">
                  <a 
                    href={pdfViewerUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className={cn(
                      "p-2 rounded-lg transition-all",
                      isDarkMode ? "text-slate-400 hover:text-blue-400 hover:bg-blue-900/30" : "text-slate-500 hover:text-blue-600 hover:bg-blue-50"
                    )}
                    title="Mở trong tab mới"
                  >
                    <ExternalLink size={20} />
                  </a>
                  <button 
                    type="button"
                    onClick={() => setPdfViewerUrl(null)} 
                    className={cn(
                      "p-2 rounded-lg transition-all",
                      isDarkMode ? "text-slate-400 hover:text-rose-400 hover:bg-rose-900/30" : "text-slate-500 hover:text-rose-600 hover:bg-rose-50"
                    )}
                  >
                    <X size={24} />
                  </button>
                </div>
              </div>
              <div className={cn(
                "flex-1 transition-colors",
                isDarkMode ? "bg-slate-950" : "bg-slate-100"
              )}>
                <iframe
                  src={pdfViewerUrl}
                  className="w-full h-full border-none"
                  title="PDF Viewer"
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Error Message Toast */}
      <AnimatePresence>
        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[110] w-full max-w-md px-4"
          >
            <div className="bg-rose-600 text-white p-4 rounded-2xl shadow-2xl flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <AlertTriangle size={20} />
                <p className="text-sm font-bold">{errorMessage}</p>
              </div>
              <button 
                type="button"
                onClick={() => setErrorMessage(null)}
                className="p-1 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirm Deletion Modal */}
      <ConfirmModal
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={confirmDelete}
        title="Xác nhận xóa thuốc"
        message={`Bạn có chắc chắn muốn xóa thuốc "${confirmData?.name}"? Hành động này không thể hoàn tác.`}
        confirmText="Xóa thuốc"
        isDarkMode={isDarkMode}
      />

      <AnimatePresence>
        {isGroupModalOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsGroupModalOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={cn(
                "relative w-full max-w-4xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col border transition-colors",
                isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
              )}
            >
              <div className={cn(
                "p-4 lg:p-6 border-b flex items-center justify-between transition-colors",
                isDarkMode ? "border-slate-800 bg-slate-900" : "border-slate-100 bg-white"
              )}>
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "p-2 rounded-xl text-white shadow-lg transition-all",
                    isDarkMode ? "bg-blue-600 shadow-none" : "bg-blue-600 shadow-blue-200"
                  )}>
                    <FolderTree size={24} />
                  </div>
                  <div>
                    <h3 className={cn("text-xl font-black transition-colors", isDarkMode ? "text-white" : "text-slate-900")}>Quản lý nhóm thuốc</h3>
                    <p className={cn("text-xs font-medium transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>Phân cấp nhóm thuốc tối đa 3 cấp</p>
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={() => setIsGroupModalOpen(false)} 
                  className={cn(
                    "p-2 rounded-xl transition-all",
                    isDarkMode ? "text-slate-400 hover:text-rose-400 hover:bg-rose-900/30" : "text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  )}
                >
                  <X size={24} />
                </button>
              </div>
              
              <div className={cn(
                "flex-1 overflow-y-auto p-4 lg:p-6 custom-scrollbar transition-colors",
                isDarkMode ? "bg-slate-950/50" : "bg-white"
              )}>
                <DrugGroupManagement 
                  isDarkMode={isDarkMode}
                  onClose={() => setIsGroupModalOpen(false)} 
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {isIngredientModalOpen && (
          <CatalogManagement
            type="ingredient"
            isDarkMode={isDarkMode}
            onClose={() => setIsIngredientModalOpen(false)}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {isIngredientCategoryModalOpen && (
          <CatalogManagement
            type="ingredient_category"
            isDarkMode={isDarkMode}
            onClose={() => setIsIngredientCategoryModalOpen(false)}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {isExcipientModalOpen && (
          <CatalogManagement
            type="excipient"
            isDarkMode={isDarkMode}
            onClose={() => setIsExcipientModalOpen(false)}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {isExcipientCategoryModalOpen && (
          <CatalogManagement
            type="excipient_category"
            isDarkMode={isDarkMode}
            onClose={() => setIsExcipientCategoryModalOpen(false)}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {isImageEditorOpen && (
          <ImageEditorModal
            isOpen={isImageEditorOpen}
            onClose={() => setIsImageEditorOpen(false)}
            imageSrc={imageToEdit}
            onConfirm={handleImageCropConfirm}
            aspect={editingImageType === 'avatar' ? 1 : 16 / 9}
            isDarkMode={isDarkMode}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {isIcdLookupOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsIcdLookupOpen(false)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={cn(
                "relative w-full max-w-4xl max-h-[85vh] flex flex-col rounded-3xl shadow-2xl overflow-hidden border",
                isDarkMode ? "bg-slate-900 border-slate-700" : "bg-white border-slate-200"
              )}
              onClick={(e) => e.stopPropagation()}
            >
              <div className={cn(
                "p-4 lg:p-6 border-b flex items-center justify-between transition-colors",
                isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-100"
              )}>
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center border",
                    isDarkMode ? "bg-blue-900/30 border-blue-800/50 text-blue-400" : "bg-blue-50 border-blue-100 text-blue-600"
                  )}>
                    <Database size={20} />
                  </div>
                  <div>
                    <h3 className={cn("text-lg font-black uppercase tracking-widest transition-colors", isDarkMode ? "text-white" : "text-slate-900")}>
                      Tra cứu mã ICD-10
                    </h3>
                    <p className={cn("text-xs font-medium transition-colors", isDarkMode ? "text-slate-400" : "text-slate-500")}>
                      Chọn mã bệnh lý để thêm vào dữ liệu thuốc
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsIcdLookupOpen(false)}
                  className={cn(
                    "p-2 rounded-xl transition-all",
                    isDarkMode ? "text-slate-400 hover:text-rose-400 hover:bg-rose-900/30" : "text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  )}
                >
                  <X size={24} />
                </button>
              </div>

              <div className="p-4 lg:p-6 flex-1 flex flex-col gap-4 overflow-hidden">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Tìm kiếm theo mã hoặc tên bệnh lý..."
                    className={cn(
                      "w-full pl-12 pr-4 py-4 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-sm font-medium",
                      isDarkMode ? "bg-slate-800 border-slate-700 text-white" : "bg-slate-50 border-slate-200"
                    )}
                    autoFocus
                  />
                  {searchTerm && (
                    <button
                      onClick={() => setSearchTerm('')}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-rose-500 transition-colors"
                    >
                      <X size={18} />
                    </button>
                  )}
                </div>

                <div className={cn(
                  "flex-1 overflow-y-auto rounded-2xl border custom-scrollbar",
                  isDarkMode ? "bg-slate-950/30 border-slate-800" : "bg-white border-slate-100"
                )}>
                  {icdList.filter(icd => 
                    (icd.code || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
                    (icd.description || '').toLowerCase().includes(searchTerm.toLowerCase())
                  ).length > 0 ? (
                    <div className="divide-y divide-slate-800/20">
                      {icdList
                        .filter(icd => 
                          (icd.code || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (icd.description || '').toLowerCase().includes(searchTerm.toLowerCase())
                        )
                        .slice(0, 100)
                        .map((icd, idx) => (
                          <button
                            key={idx}
                            onClick={() => {
                              if (icdLookupTarget) {
                                if (icdLookupTarget.type === 'contraindication') {
                                  const newList = [...formData.contraindications];
                                  const currentIcd10s = newList[icdLookupTarget.index].icd10s || [];
                                  const fullCode = `${icd.code} - ${icd.description}`;
                                  if (!currentIcd10s.includes(fullCode)) {
                                    newList[icdLookupTarget.index] = { 
                                      ...newList[icdLookupTarget.index], 
                                      icd10s: [...currentIcd10s, fullCode] 
                                    };
                                    setFormData({ ...formData, contraindications: newList });
                                  }
                                } else if (icdLookupTarget.type === 'indication') {
                                  const newList = [...formData.indications];
                                  const currentIcd10s = newList[icdLookupTarget.index].icd10s || [];
                                  const fullCode = `${icd.code} - ${icd.description}`;
                                  if (!currentIcd10s.includes(fullCode)) {
                                    newList[icdLookupTarget.index] = {
                                      ...newList[icdLookupTarget.index],
                                      icd10s: [...currentIcd10s, fullCode]
                                    };
                                    setFormData({ ...formData, indications: newList });
                                  }
                                }
                              }
                              setIsIcdLookupOpen(false);
                            }}
                            className={cn(
                              "w-full text-left p-4 transition-all flex items-start gap-4 group",
                              isDarkMode ? "hover:bg-blue-900/20" : "hover:bg-blue-50"
                            )}
                          >
                            <div className={cn(
                              "px-2 py-1 rounded-lg text-[10px] font-black border uppercase tracking-wider shrink-0 transition-colors",
                              isDarkMode ? "bg-blue-500/10 text-blue-400 border-blue-500/20 group-hover:border-blue-400/30" : "bg-blue-50 text-blue-600 border-blue-100 group-hover:border-blue-200"
                            )}>
                              {icd.code}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className={cn("text-xs font-bold leading-relaxed mb-0.5", isDarkMode ? "text-slate-200" : "text-slate-700")}>
                                {icd.description}
                              </p>
                              {icd.category && (
                                <p className="text-[10px] text-slate-500 italic">{icd.category}</p>
                              )}
                            </div>
                            <div className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                              <div className={cn(
                                "w-8 h-8 rounded-full flex items-center justify-center",
                                isDarkMode ? "bg-blue-900/40 text-blue-400" : "bg-blue-100 text-blue-600"
                              )}>
                                <Plus size={14} />
                              </div>
                            </div>
                          </button>
                        ))
                      }
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-20 px-4 text-center">
                      <div className={cn(
                        "w-16 h-16 rounded-3xl flex items-center justify-center mb-4",
                        isDarkMode ? "bg-slate-900 text-slate-600" : "bg-slate-50 text-slate-300"
                      )}>
                        <Search size={32} />
                      </div>
                      <h4 className={cn("text-sm font-bold mb-1", isDarkMode ? "text-slate-300" : "text-slate-600")}>Không tìm thấy kết quả</h4>
                      <p className={cn("text-xs", isDarkMode ? "text-slate-500" : "text-slate-400")}>Thử tìm kiếm với từ khóa khác hoặc mã ICD-10 khác</p>
                    </div>
                  )}
                </div>
              </div>

              <div className={cn(
                "p-4 border-t flex items-center justify-between",
                isDarkMode ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-100"
              )}>
                <p className="text-[10px] text-slate-500 font-medium">Tìm thấy {icdList.length} mã ICD-10 trong hệ thống</p>
                <button
                  onClick={() => setIsIcdLookupOpen(false)}
                  className={cn(
                    "px-4 py-2 rounded-xl text-xs font-bold transition-all",
                    isDarkMode ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-50"
                  )}
                >
                  Đóng
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isCompanyModalOpen && (
          <CatalogManagement
            type="company"
            isDarkMode={isDarkMode}
            onClose={() => setIsCompanyModalOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Floating Action Button for Adding Drug */}
      {canManage && !isGroupModalOpen && !isIngredientModalOpen && !isIngredientCategoryModalOpen && !isExcipientModalOpen && !isExcipientCategoryModalOpen && !isCompanyModalOpen && !isModalOpen && !isReviewModalOpen && (
        <button
          type="button"
          onClick={() => {
            if (viewMode === 'groups') setIsGroupModalOpen(true);
            else if (viewMode === 'ingredients') setIsIngredientModalOpen(true);
            else if (viewMode === 'excipients') {
              if (excipientView === 'categories') setIsExcipientCategoryModalOpen(true);
              else setIsExcipientModalOpen(true);
            }
            else if (viewMode === 'companies') setIsCompanyModalOpen(true);
            else handleOpenModal();
          }}
          className={cn(
            "fixed bottom-20 lg:bottom-10 right-6 lg:right-10 z-[60] w-14 lg:w-16 h-14 lg:h-16 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110 active:scale-95 group",
            "shadow-blue-500/40",
            selectedDrug && "hidden lg:flex"
          )}
          title={viewMode === 'groups' ? "Thêm nhóm mới" : viewMode === 'ingredients' ? "Thêm hoạt chất mới" : viewMode === 'excipients' ? "Thêm tá dược mới" : viewMode === 'companies' ? "Thêm công ty mới" : "Thêm thuốc mới"}
        >
          <div className="relative">
            <Plus size={32} className="group-hover:rotate-90 transition-transform duration-300" />
          </div>
        </button>
      )}
      <DrugDetailModal 
        isOpen={isDetailModalOpen} 
        onClose={() => setIsDetailModalOpen(false)} 
        drug={detailDrug} 
        isDarkMode={isDarkMode} 
      />
    </div>
  );
};

export default DrugDirectory;
